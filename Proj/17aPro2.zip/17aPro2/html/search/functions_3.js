var searchData=
[
  ['enemy',['Enemy',['../class_enemy.html#a94f30d348b6d2840fd71675472ba38dd',1,'Enemy::Enemy()'],['../class_enemy.html#a9719f9eedddb5950fc1e522051a93d93',1,'Enemy::Enemy(const Enemy &amp;orig)']]]
];
