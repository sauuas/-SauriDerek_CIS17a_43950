var searchData=
[
  ['introspection',['Introspection',['../class_introspection.html#a77d56e88c793d64dac4defaaa6113458',1,'Introspection::Introspection()'],['../class_introspection.html#ac325018f354eb5b8961aa1a96f668052',1,'Introspection::Introspection(int, int, int)'],['../class_introspection.html#ae4629d40d0e021fbee1830097f3eeb58',1,'Introspection::Introspection(const Introspection &amp;orig)']]]
];
