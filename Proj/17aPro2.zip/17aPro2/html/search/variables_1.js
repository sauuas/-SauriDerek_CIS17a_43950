var searchData=
[
  ['choices',['choices',['../struct_player.html#a3416537dfa94fa27b5fcf1d197dd5581',1,'Player']]]
];
