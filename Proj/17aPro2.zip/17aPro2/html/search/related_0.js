var searchData=
[
  ['attack',['attack',['../class_character.html#aeff8f0cb8fe6cdd98e5aa242b122da93',1,'Character']]],
  ['lifesteal',['lifeSteal',['../class_character.html#ae8509afb5c04b29e3af5b15c0d15c176',1,'Character']]]
];
