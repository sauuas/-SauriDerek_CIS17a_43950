var indexSectionsWithContent =
{
  0: "abcdefghilmnopstvw~",
  1: "cefghipsv",
  2: "cefghimpsv",
  3: "abcefghilmopsv~",
  4: "acdehnps",
  5: "c",
  6: "abhinpstw",
  7: "fg"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "enums",
  6: "enumvalues",
  7: "related"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Enumerations",
  6: "Enumerator",
  7: "Friends"
};

