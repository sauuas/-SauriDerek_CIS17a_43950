var searchData=
[
  ['getdefence',['getDefence',['../class_character.html#ae7f715ff44c45f0e91f8bda1edb8a1d6',1,'Character::getDefence()'],['../class_enemy.html#a9d18309787114c720014ca41745bc848',1,'Enemy::getDefence()']]],
  ['getelementat',['getElementAt',['../class_vec.html#a3f13f26ce9e609d319a39e59a6ee0ed0',1,'Vec']]],
  ['gethealth',['getHealth',['../class_character.html#ae24a44b8a22d0727dd4e2c46a1df66f5',1,'Character::getHealth()'],['../class_enemy.html#a46341636350ca2bc6aac929b2a84f215',1,'Enemy::getHealth()']]],
  ['getstrength',['getStrength',['../class_character.html#a8ccbb82b13e59f02c9df0b321fae577d',1,'Character::getStrength()'],['../class_enemy.html#a7cf575af3b106e3b5e86bd2a031e2911',1,'Enemy::getStrength()']]],
  ['ghoul',['Ghoul',['../class_ghoul.html#a8d76b68014d35962c4651dc28e536725',1,'Ghoul::Ghoul()'],['../class_ghoul.html#a072fe58a39f2f5db91edae58f580092f',1,'Ghoul::Ghoul(int, int, int)'],['../class_ghoul.html#ac4747251c2df17333d9242459d7608e9',1,'Ghoul::Ghoul(const Ghoul &amp;orig)']]]
];
