var searchData=
[
  ['name',['name',['../struct_player.html#a4af4a10433f33834b59d0c3793358a40',1,'Player']]]
];
