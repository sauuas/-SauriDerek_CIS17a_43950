var searchData=
[
  ['spellbinder',['SPELLBINDER',['../_enums_8h.html#af0c181dac34da376a1aa0b98624a2b58a8d84a44b2d402e91aea53ef5f09abd86',1,'Enums.h']]],
  ['stalemate',['STALEMATE',['../_enums_8h.html#aba5e864526cbaa667bca74e2d1d453f0a5d52fbb867b34eb59327ec0a99d421f6',1,'Enums.h']]],
  ['superior',['SUPERIOR',['../_enums_8h.html#ab4c2e29f0027cddbda43c092248a07b9a5a6c75ba45d46d6bb08bbceb9343d425',1,'Enums.h']]]
];
