var searchData=
[
  ['spellbinder',['Spellbinder',['../class_spellbinder.html',1,'']]]
];
