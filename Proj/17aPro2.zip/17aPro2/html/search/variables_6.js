var searchData=
[
  ['pclass',['pClass',['../struct_player.html#a7599637a619e52fbafb9828f38176a1b',1,'Player']]]
];
