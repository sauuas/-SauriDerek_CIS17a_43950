var searchData=
[
  ['take',['TAKE',['../_enums_8h.html#af6b128bfb9b22174e084962314cd68c2a7405647410e343caba1bf383e83d4f5f',1,'Enums.h']]]
];
