var searchData=
[
  ['defence',['defence',['../class_character.html#a50ebb0d97ab2ec99d1ec03ed8d881a6b',1,'Character::defence()'],['../class_enemy.html#a00fc57224d0b02bc9369de3886ea811b',1,'Enemy::defence()']]]
];
