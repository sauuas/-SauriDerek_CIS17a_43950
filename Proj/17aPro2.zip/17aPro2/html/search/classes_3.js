var searchData=
[
  ['ghoul',['Ghoul',['../class_ghoul.html',1,'']]]
];
