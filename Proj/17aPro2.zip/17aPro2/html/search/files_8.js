var searchData=
[
  ['spellbinder_2ecpp',['Spellbinder.cpp',['../_spellbinder_8cpp.html',1,'']]],
  ['spellbinder_2eh',['Spellbinder.h',['../_spellbinder_8h.html',1,'']]],
  ['spellbinder_2eo_2ed',['Spellbinder.o.d',['../_spellbinder_8o_8d.html',1,'']]]
];
