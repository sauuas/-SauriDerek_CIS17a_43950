var searchData=
[
  ['health',['health',['../class_character.html#a69c649b8febd22729e6edafb27e69aeb',1,'Character::health()'],['../class_enemy.html#aedd5e7bf8ef07ee97be433c853a10d8d',1,'Enemy::health()']]]
];
