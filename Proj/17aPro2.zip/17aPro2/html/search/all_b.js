var searchData=
[
  ['name',['name',['../struct_player.html#a4af4a10433f33834b59d0c3793358a40',1,'Player']]],
  ['not',['NOT',['../_enums_8h.html#af6b128bfb9b22174e084962314cd68c2a0378ebc895849163b249d0b330257dd6',1,'Enums.h']]]
];
