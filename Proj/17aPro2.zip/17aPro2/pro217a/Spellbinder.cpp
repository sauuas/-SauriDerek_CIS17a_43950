/* 
 * File:   Spellbinder.cpp
 * Author: derek
 */

#include "Spellbinder.h"
#include <iostream>

using namespace std;

Spellbinder::Spellbinder() {
    this->defence = 0;
    this->health = 0;
    this->strength = 0;
}
Spellbinder::Spellbinder(int h, int a, int d) {
    this->strength = a;
    this->defence = d;
    this->health = h;
}
void Spellbinder::attack(Enemy& en, int num){
     int n = num - en.getDefence();
    if(n < 0) n = 0;
    en.setHealth(en.getHealth()- n);
    if(en.getHealth() < 0) en.setHealth(0);
    cout << "damage dealt: " << n << endl;
}
//increase defense
void Spellbinder::special(){
    this->defence = defence * 2;
}
Spellbinder::Spellbinder(const Spellbinder& orig) {
    defence = orig.defence;
    health = orig.health;
    strength = orig.strength;
}
Spellbinder::~Spellbinder() {
}