/* 
 * File:   Ghoul.cpp
 * Author: Derek Sauri
 */

#include "Ghoul.h"
#include "Character.h"
#include <iostream>

using namespace std;

Ghoul::Ghoul(){
    this->health = 0;
    this->strength = 0;
    this->defence = 0;
}
Ghoul::Ghoul(int h, int str, int def) {
    this->setHealth(h);
    this->setStrength(str);
    this->setDefence(def);
}
Fiend Ghoul::operator +(Ghoul& other){
    Fiend theFiend(health + other.health,strength + other.strength, 
                                defence + other.defence);
    this->~Ghoul();
    other.~Ghoul();
    return theFiend;
}
void Ghoul::attack(Character& en, int num){
    int n = num - en.defence;
    if(n < 0) n = 0;
    en.health -= n;
    if(en.health < 0) en.health = 0;
    cout << "damage dealt to you: " << n << endl;
}
Ghoul::Ghoul(const Ghoul& orig) {
}
Ghoul::~Ghoul() {
}