/* 
 * File:   Spellbinder.h
 * Author: derek
 */

#ifndef SPELLBINDER_H
#define	SPELLBINDER_H
#include "Character.h"
#include "Enemy.h"

class Spellbinder: public Character {
public:
    Spellbinder();
    Spellbinder(int,int,int);
    Spellbinder(const Spellbinder& orig);
   void attack(Enemy&, int);
   void special();
    virtual ~Spellbinder();
};
#endif	/* SPELLBINDER_H */