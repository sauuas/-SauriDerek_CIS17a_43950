/* 
 * File:   Fiend.cpp
 * Author: Derek Sauri
 */

#include "Fiend.h"
#include "Character.h"
#include <iostream>

using namespace std;

Fiend::Fiend(int h, int str, int def){
    this->health = h;
    this->strength = str;
    this->defence = def;
}
void Fiend::lifeSteal(Character& player){
    int num = player.health/5;
    player.health -= num;
    this->health += num;
}
Fiend::Fiend(const Fiend& orig) {
    this->defence = orig.defence;
    this->health = orig.health;
    this->strength = orig.strength;
}
void Fiend::attack(Character& en, int num){
    int n = num - en.defence;
    if(n < 0) n = 0;
    en.health -= n;
    if(en.health < 0) en.health = 0;
    cout << "damage dealt to you: " << n << endl;
}
Fiend::~Fiend(){
}