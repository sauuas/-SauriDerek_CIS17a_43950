/* 
 * File:   Introspection.cpp
 * Author: derek
 */

#include "Introspection.h"
#include "Enemy.h"
#include <iostream>

using namespace std;

Introspection::Introspection() {
    this->defence = 0;
    this->health = 0;
    this->strength = 0;
}
Introspection::Introspection(int h, int a, int d) {
    this->strength = a;
    this->defence = d;
    this->health = h;
}
void Introspection::attack(Enemy& en, int num){
    int n = num - en.getDefence();
    if(n < 0) n = 0;
    en.setHealth(en.getHealth()- n);
    if(en.getHealth() < 0) en.setHealth(0);
    cout << "damage dealt: " << n << endl;
}
//temporary boost to attack
void Introspection::special(){
   this->strength = strength*2;
}
Introspection::Introspection(const Introspection& orig) {
    defence = orig.defence;
    health = orig.health;
    strength = orig.strength;
}
Introspection::~Introspection() {
}