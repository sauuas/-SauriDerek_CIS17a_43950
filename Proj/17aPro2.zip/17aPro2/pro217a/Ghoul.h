/* 
 * File:   Ghoul.h
 * Author: Derek Sauri
 */

#ifndef GOUL_H
#define	GOUL_H
#include "Enemy.h"
#include "Fiend.h"

class Character;

class Ghoul: public Enemy {
public:
    Ghoul();
    Ghoul(int, int, int);
    void attack(Character &en, int num);
    Fiend operator +(Ghoul&);
    Ghoul(const Ghoul& orig);
    virtual ~Ghoul();
private:
};
#endif	/* GOUL_H */