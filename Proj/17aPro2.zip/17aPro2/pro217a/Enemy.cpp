/* 
 * File:   enemy.cpp
 * Author: Derek
 */
#include "Enemy.h"

Enemy::Enemy() {
}
Enemy::Enemy(const Enemy& orig) {
    this->defence = orig.defence;
    this->health = orig.health;
    this->strength = orig.strength;
}
Enemy::~Enemy() {
}