/* 
 * File:   final project 17a
 * Author: Derek Sauri
 */
///system libraries
#include <iostream>
#include <stdlib.h>     ///for exit command
#include <windows.h>    ///for sleep command
#include <exception>    //throwing runtime exceptions
#include <fstream>

///user libraries
#include "Player.h"
#include "Character.h"
#include "Enums.h"
#include "Harmony.h"
#include "Introspection.h"
#include "Spellbinder.h"
#include "Ghoul.h"
#include "Vec.h"

using namespace std;
///prototypes
Player begin();
Player load();
void save(Player);
Player part1(Player);
Player part2(Player);

/// /fn menu for game run in main
int main(){
    char choice;
    Player player;
    
    do{
        cout << "text adventure\n\n";
        cout << "A: new game\n";
        cout << "B: load save\n";
        cout << "E: quit\n";
        cin >> choice;
        switch(toupper(choice)){
            case'A':  try{    
                    player = begin(); 
                   }
                    catch(exception& e){
                        cout << "exception: " << e.what() << endl;
                    }
            break;
            case'B':
                try{    
                    player = load();
                   }
                    catch(exception& e){
                        cout << "exception: " << e.what() << endl;
                    }
            break;
            case'E': return 0;
            break;
            default: cout << "invalid option, chose again\n\n";
        }
    }while(toupper(choice) != 'A' &&toupper(choice) != 'B');
    if(player.choices[1] == 65) player = part1(player);
    if(player.choices[2] == 65) player = part2(player);
    delete []player.name;
    cout << "thank you for playing the demo version\n\n";
    return 0;
}
/// /fn save to file
void save(Player player){
    ofstream file;
    
    file.open("playersave.dat", ios::binary | ios::out | ios::trunc);
    file.write(reinterpret_cast<char *>(&player.size), sizeof(player.size));
    file.write(player.name, sizeof(player.name));
    file.write(reinterpret_cast<char *>(&player.pClass), sizeof(player.pClass));
    file.write(reinterpret_cast<char *>(&player.choices), sizeof(player.choices));
    file.close();
}
/// /fn loads save file
//TODO fix weird loading errors
Player load(){
    ifstream file;
    Player player;
    
    try{
        throw 3;
        
        file.open("playerSave.dat", ios::binary | ios::in);
    }catch(exception& e){
        cout << e.what() << endl;
    }
    catch(int e){
        cout << "something happened\n";
        exit(EXIT_FAILURE);
    }
     if(file.fail()) cout << "file failed\n\n";
    file.seekg(ios::beg);
    file.read(reinterpret_cast<char *>(player.size), sizeof(player.size));
    player.name = new char[player.size];
    file.read(player.name, sizeof(player.name));
    file.read(reinterpret_cast<char *>(player.pClass), sizeof(player.pClass));
    file.read(reinterpret_cast<char *>(player.choices), sizeof(player.choices));
    file.close();
    cout << "load successful\n";
    return player;
}    
/// /fn set up story and class
Player begin(){
    Player player;
    string name;
    char ch;            ///used to hold choices
    
    /// set up the story here after the name
    cout << "This world runs on the magical energies that emanate from the next.\n\n";
    Sleep(3000);
    cout << "The spirit realm or magic realm is a plane of existence in which\n"
            "matter, forces, and reality in general is much flexible and malleable\n"
            "than our own.\n\n";
    Sleep(5000);
    cout << "That plane of existence has immense flexibility, and the spirits\n"
            "that live there take full advantage of this fact; However, spirits\n"
            "are as malleable as the realm they dwell in, able to change their\n"
            "form as the purpose the spirit lives for demands.\n\n";
    Sleep(7000);
    cout << "while our steady and independent world can only pass into that realm,\n"
            " in one's dreams, pieces of the spirit realm may materialize in our realm,\n"
            "whether it does so on its own, or a person commands it to do so.\n\n";
    Sleep(7000);
    cout << "those who can command the pieces of the spirit world to do and become\n"
            "what one wishes, is known as a mage.\n\n";
    Sleep(5000);
    cout <<"Average folk are not directly in tune with this world, and thus cannot\n"
            "access its uses as the magi do.\n\n";
    Sleep(5000);
    cout << "you are a mage first entering the halls of the local academy of magi\n"
            "in your hometown, this was the only place you could go since your family\n"
            "disowned you.\n\n";
    Sleep(7000);
    cout << "(your Headmaster approaches)\n\n";
    Sleep(1500);
    cin.ignore();
    cout << "\"what is your name?\"\n";
    getline(cin,name);
    while(!cin){
        cin.clear();
        cin.ignore(999,'\n');
        cout << "invalid input, please reenter";
        getline(cin,name);
    }
    player.size = name.length();
    player.name = new char[player.size];
    for(int i = 0; i < 3; i++) player.choices[i] = 65;
    for(int i =0; i < player.size; i++) player.name[i] = name[i];
    ///determine class decision
    cout << "\"" << player.name <<"\", is it?, what a peculiar name.\"\n\n";
    Sleep(1500);
    cout << "\"well, in any case, the first thing i need to know about you is what\n"
            "will you be studying while you are here, so i may better direct you "
            "to the proper instructor.\"\n\n"; Sleep(5000);
    cout << "\"while there are multitudes of subjects regarding magical inquiry,\n"
            "the are three major paths to begin one's journey. the path of harmony,\n"
            "the path of introspection, and the path of spell binding.\n\n";Sleep(5000);
    do{
    cout <<   "which would you like to hear more about?\"\n\n";
    cout << "A: path of harmony\n"
            "B: path of introspection\n"
            "C: path of spell binding\n";
            cin >> ch;
            switch(toupper (ch)){
                case 'A':   player.pClass = HARMONY;
                    cout <<"\"the path of harmony focuses on attuning one's being\n"
                            " to that of the natural world, of course, including\n"
                            "the magic realm.\"\n\n";Sleep(7000);
                    cout << "this path draw strength from the surrounding environment,"
                            "able to enhance one senses to beyond the usual, attune\n"
                            "to the spirit world at will for guidance with spirits,\n"
                            "and can integrate one's magic as an extension of one's\n"
                            "being.\n\n";Sleep(7000);
                    cout << " all this integration with magic allow one great\n"
                            "resilience to magic used against you since you can just\n"
                            "attune yourself to the magic and absorb it to your being\n\n";
                            Sleep(7000);
                    cout << "it may sound like simple and pleasant, but this path is not\n"
                            "for everyone. it requires harsh discipline and self\n"
                            "control in order to keep one's person quiet\n"
                            "and attuned with the world, else it corrupts you\n"
                            "from without and within, since your magic is almost\n"
                            "literally part of you, just keep yourself pure and your\n"
                            "magic pure...er.\"\n\n"; Sleep(10000);break;
                case 'B':   player.pClass = INTROSPECTION;
                    cout << "\"the path of introspection has little to do with\n"
                            "'looking' within one person and more about cementing it.\n\n";
                                Sleep(5000);
                    cout << "this path focuses on the strength of one's inner being\n"
                            "and sense of self to better directly manipulate and\n"
                            "control magic.\n\n";Sleep(5000);
                    cout << "one who follows this path typically uses more volatile\n"
                            "and unstable magical arts, and is quite adapt at taming\n"
                            "higher quantities of magic at a time as well as the less\n"
                            "pleasant spirits to due their bidding, the high willpower\n"
                            "helps to ward off potential corruption from magical\n"
                            "backfire as well.\n\n";Sleep(7000);
                    cout << "drawbacks typically associated with this path draw\n"
                            "from the unstable nature of the magic one will learn.\n"
                            "volatile magic is not known for being safe or easily\n"
                            "maintained, so don't try to store lightning bolts like\n"
                            "fireworks or other such nonsense. also, your magic can\n"
                            "easily corrupt or interfere with around you, should your will\n"
                            "falter when this happens, you will lose control of your powers\"\n\n";
                                Sleep(10000);
                    break;
                case 'C':   player.pClass = SPELLBINDER;
                    cout << "\"the path of spell binding is mainly for those who wish\n"
                            "to focus more on giving magic form rather than more direct\n"
                            "applications.\"\n\n";Sleep(5000);
                    cout << "\"this does not mean you will not learn direct magic, you\n"
                            "just won't be manipulating primal forces or communing with\n"
                            "the spirit world the same way as the other paths. \n\n";Sleep(5000);
                    cout << "instead, you "
                            "will create glyphs, enchantments, and other logical constructs\n"
                            "for giving magic a direct form, thus 'binding' magic to a form\n"
                            "without having to sustain it yourself. this path thus can create\n"
                            "and store magical constructs without draining yourself in the process\n"
                            "and is the best path for binding whole spirits to do your bidding. many\n"
                            "of the magical items and economical products magic can produce come from\n"
                            "those who walk this path as well\n\n";Sleep(7000);
                    cout << "of course, as with all the paths, spell binding has a few shortcomings.\n"
                            "because you will be learning to bind magic and not actively use it, you\n"
                            "will not be able to directly control what the binding does, you can only\n"
                            "use your knowledge to give magic a form to perform your purpose, this can be\n"
                            "much harder than it sounds, especially when dealing with spirits.\n\n";Sleep(8000);
                    cout << "the bindings "
                            "can create further complications, since poorly-made or advance bindings usually have\n"
                            "activation conditions that will need to be met in order for the binding to function\n"
                            "such as a spirit can only assist you if you are in a body of water. it may sound silly\n"
                            "but such conditions may be necessary to create ways to manifest powerful spirits in our world.\n"
                            "creating good bindings takes a logical and creative mind set but\n"
                            "can be rather powerful if the path is taken seriously.\"\n\n";Sleep(7000);
                            break;
                default: cout << "that is not an option, please pick a valid path\n\n";
                            
            }
            if(toupper(ch) != 'A' ||toupper(ch) != 'B'||toupper(ch) != 'C'){
                cout << "is this the path you choose?(y or N)\n";
                cin >> ch;
                
            }
            else{
                ch = 'N';
                continue;
            }
    }while(toupper(ch) != 'Y');
    cout << "\"That path?, not my favorite but to each his own, on to more important matters\n\n";Sleep(3000);
    cout << "as you may well know, our kind is not taken well by others who\n"
            "do not share our talents.\"\n\n";Sleep(5000);
    cout << "\"while there are those who find magic to be useful, many still fear\n"
            "mages will bring ruin and destruction by tapping into the spirit realm\n\n";Sleep(5000);
            
    ///decision to determine character opinion to non-mage characters
            cout << "what is your opinion on how the others view us?\n\n";
            cout << "A: \"i don't know what to think about this topic\"\n"
                    "B: \"let the commoners think what they want, they are beneath us\"\n"
                    "C: \"they're not gonna try to burn us at the stake right?\"\n"
                    "D: \"i hate the commoners for making us to be monsters or just tools\"\n";
            cin >> ch; cin.ignore();
            switch(toupper(ch)){
                case 'A': player.choices[0] = INDIFFERENT; break;
                case 'B': player.choices[0] = SUPERIOR; break;
                case 'C': player.choices[0] = PLAYFUL; break;
                case 'D': player.choices[0] = ANGRY; break;
                default:  player.choices[0] = INDIFFERENT; break;
            }
            cout << "\" all right then, interesting to add to your profile, your class\n"
                    "is that way\n";
                    Sleep(1500);
                    cout << ".";
                    Sleep(1500);
                    cout << ".";
                    Sleep(1500);
                    cout << ".";
            cout << " go to your class\n\n"; Sleep(3000);
            cout << "you walk to your first class\n\n";Sleep(5000);
            save(player);
            cout << "do you wish to continue? (Y or N)\n";
            cin >> ch; cin.ignore();
            if(toupper(ch) != 'Y') {
                delete []player.name;
                exit(0);
                
            }
            return player;
}
/// part one of story
Player part1(Player player){
    char ch;
    ///first class to understand more of magic path
    if(player.pClass == HARMONY){
        cout << "\"if you wish to understand nature and our reality at its most\n"
                "fundamental level, then you came to the right place, my name is\n"
                "professor Weinstein.\"\n\n";Sleep(5000);
        cout << "you will not need textbooks for this course, as nature is all around us,\n"
                "if we learn to listen and appreciate it, it rewards us with insight\n"
                "to what you may currently consider to be 'reality'\n\n";Sleep(5000);
        cout << "(random student) \" i thought we could integrate magic directly into our selves,\n"
                "when our we going to learn about that?\"\n\n";Sleep(5000);
        cout << "(professor Weinstein)\"those techniques can only be practiced once you make your body\n"
                "a vessel that can hold magic as it is, in order to be that vessel, one must learn to\n"
                "diminish the ego\n\n";Sleep(5000);
        cout << "pride, desires that conflict with nature, and other emotions that\n"
                "invoke a strong sense of self currently fill up the vessel that can\n"
                "hold such magic, and these same emotions can corrupt magic when it is "
                "in you\n\n";Sleep(5000);
        cout << "since too much can go wrong with attempting to integrate magic now,\n"
                "let us start by simply learning to sense a person's emotions through\n"
                " the surrounding ambient magic...\n\n"; Sleep(5000);
        cout << "(you learn to sense a person's emotions and a basic repulse spell)\n\n";Sleep(3000);     
    }
   if(player.pClass == INTROSPECTION){
       cout << "\"This class is for those who wish to follow a path that leads to immense power.\n\n";Sleep(3000);
       cout << "as a warning, those of you who do not belive yourself to be a strong and\n"
               "deserving individual may have a hard time developing your willpower to control\n"
               "the magic taught here, and will die, and thus should leave now\n"
               " for everyone else, my name is professor Quinn.\"\n\n";Sleep(5000);
        cout << "\"now that introductions are out of the way, let us begin with the basics\n";Sleep(3000);
        cout << "when magi such as yourselves cast spells, they do so by giving form to the\n"
                "pieces of the spirit realm that cross to our own, what we and the commoners\n"
                "refer to as 'magic'\n\n";Sleep(5000);
        cout << "our kind focus on channeling our person into the magic to better\n"
                "control magic and bend the laws of nature far beyond what the other paths\n"
                "are capable of achieving.\"\n\n";Sleep(5000);
        cout << "(random student) \"but i heard from other instructors imposing your\n"
                "will on forces of nature can pervert it and lead to corruption\"\n\n";Sleep(5000);
        cout << "(professor Quinn) \"when you do not pay attention to the way you use your magic then yes,\n"
                "one can break the natural flow between the spirit world and the magic world,\n"
                "but if you can truly control your magic, then you can maintain balance while\n"
                "distorting space for example, and one can tame demons with enough practice\n"
                "and willpower. thus, let us begin with focusing the magic within you and\n"
                "the ambient magic surrounding you.\"\n";Sleep(7000);
        cout << "(you learn to overcharge your basic spell, repulse)\n\n";Sleep(3000);      
    }
    if(player.pClass == SPELLBINDER){
        cout << "\"hello class, i am your professor, you all may refer to me as such,\n"
                "unless you have a better name to call me, i will show you my approval\n"
                "by not binding a wisp to you that will make your skin feel like its\n"
                "crawling with beetles that are on fire, any questions?\"\n\n";Sleep(7000);
        cout << "(stunned silence)\n\n";
        Sleep(3000);
        cout << "\"if there no questions, let us begin\"\n\n";
        Sleep(3000);
        cout << "\"binding practices are all about giving the little pieces of the spirit\n"
                "world we call magic a form in a more direct sense than other disciplines.\n\n";
        cout << "the form is the most important part for a binder, the function of the\n"
                "binding follows the form it is placed in.\n\n";Sleep(7000);
        cout << "due to this emphasis on the form we give magic, you all will be learning\n"
                "all he different way you can bind magic such as glyphs, enchantments,\n"
                "and spirits as well, properly bound spirits hold no danger to the master,\n"
                "since you can create it to follow your commands however you like\"\n\n";Sleep(7000);
        cout << "it is important to mention that when you begin binding spirits, you will\n"
                "start with tiny wisps, since they have no real will of their own and\n"
                "can be compounded together like Lego pieces, you are not CREATING spirits\n"
                "you are binding them into a new form for your purposes.\"\n\n";Sleep(7000);
        cout << "(random student)\"so bindings cannot be controlled then?\n\n";Sleep(5000);
        cout << "(professor) \"you could not be more wrong and right at the same time\n"
                "you clever moron you\n\n";Sleep(5000);
        cout << "bindings typically are not directly controlled by the one using the binding\n"
                "since bindings can be created to perform tasks that would be difficult for\n"
                "a mage to perform on their own such as regulating the behavior of powerful\n"
                "spirits or dealing with corrupted magic, but the binder can create ways of\n"
                "safely interacting with the bindings so as to avoid micromanaging the binding.\n"
                "also important to mention, we don't have to train our person like other paths,\n"
                "we just simply have to know what we are doing.\n\n";Sleep(10000);
        cout << "now that questions are answered, let us, well you, perform your first binding,\n"
                "it's not something you make into a sword or whatever but it helps to train\n"
                "you young ones\n\n";Sleep(7000);
        cout << "(you learn to create a glyph that repels everything around it)\n\n";Sleep(3000);
    } 
    cout << "(you are walking to your dome room when an odd man bumps into you and continues walking)\n\n";
    Sleep(3000);
    cout << "A: turn around and say something\n";
    cout << "B: turn around and see what the man is doing\n";
    cout << "C: ignore him and keep walking\n";
    if(player.pClass == HARMONY) cout << "D:see person's emotional state\n";
    cin >> ch; cin.ignore();
    switch(toupper(ch)){
        case 'A':cout << "(you)\"hey! watch where you're going!\n\n";Sleep(3000);break;
        case 'B':cout << "(he becomes nervous as he notices you watching him)\n\n";Sleep(3000); break;
        case 'C':cout << "(you feel his presence still lurking around you)\n\n";Sleep(3000); break;
    }
    if(player.pClass == HARMONY && toupper(ch) == 'D'){
           if(player.choices[0] == SUPERIOR ||player.choices[0] == ANGRY ){
               cout << "your feelings towards normal people clouds your vision\n\n";Sleep(3000);
           }
           else {
               cout << "you sense he has murderous intentions circling you\n\n";Sleep(3000);
           }
           if(player.pClass == HARMONY && player.choices[0] != SUPERIOR && player.choices[0] != ANGRY){
        cout << "your insight into what the man was feeling tells you to incapacitate him\n"
                "with a repulse spell\n\n";Sleep(3000);
                player.choices[1] = WON;
    }
       }
    
    else if(toupper(ch) == 'A' || toupper(ch) == 'B' || player.choices[0] == ANGRY ||player.choices[0] == SUPERIOR){
            cout << "the man freaks out and lunges at you with a knife\n\n";Sleep(3000);
            cout << "what do you do?\n\n";
            cout << "A: run\n";
            cout << "B: cast repulse spell\n";
            if(player.pClass == SPELLBINDER)cout <<"C: cast glyph on yourself\n";
            cin >> ch; cin.ignore();
            
                if(toupper(ch) == 'A'){ cout << "you try to escape but the man sticks his knife into\n"
                        "your back, taking you down, other mages chase him off\n\n";
                player.choices[1] = BEATEN; 
                }
                else if(toupper(ch) == 'B'){ 
                    if(player.pClass == INTROSPECTION){
                    cout <<"your repulse spell is so powerful it knocks the man out cold\n\n";Sleep(3000);
                    player.choices[1] = WON;
                    }
                    else{
                    cout << "you repel him to the ground but the man throws\n"
                            "the knife at you, slicing you as it passes by, the man escapes\n\n";Sleep(3000);
                        player.choices[1] = STALEMATE;
                        }
                }
                if(player.pClass == SPELLBINDER && toupper(ch) == 'C'){
                     cout << "the man tries to stab you, but the glyph repels the\n"
                            "man, when he tries to throw his knife at you, it repels away\n"
                            "from you and into his foot, you use a repulse spell to incapacitate him\n\n";Sleep(3000);
                    player.choices[1] = WON;
                }
            
    }
    else if(toupper(ch) == 'C'){
        if(player.pClass == SPELLBINDER){
            cout << "you cast a repulse glyph on yourself to feel safer, then the man\n"
                    "tries to lunge at you with a knife, the glyph repels him, but he\n"
                    "runs away before you can do anything else\n\n";Sleep(3000);
            player.choices[1] = STALEMATE;
        }
        else{
             cout << "you begin to walk faster in order to feel safer, then the man\n"
                    "tries to lunge at you with a knife, digging it into your back,\n"
                     "you collapse";Sleep(3000);
             cout << "a few hours later, you awake to find yourself surrounded by mages,\n"
                     "who seemed to have chased off the man who attacked you.\n\n";Sleep(3000);
             player.choices[1] = BEATEN;
        }
    }
    save(player);
    cout << "do you wish to continue? (Y or N)\n";
            cin >> ch; cin.ignore();
            if(toupper(ch) != 'Y'){
                exit(0);
            }
    return player;
}
//part 2, more active part of story
Player part2(Player player){
    char ch;
    
    cout << "you are in a hospital setting\n\n";
    Sleep(5000);
    if(player.choices[1] == WON){
        cout << "you find the assailant incapacitated there, your handiwork\n\n";
        Sleep(3000);
        cout << "he had an insignia on his arm, detailing he worked with and was"
                "branded by magi who practice forbidden arts, including but not "
                "limited to enslaving the minds of others\n\n";
        Sleep(5000);
    }
    else{
        if(player.choices[1] == STALEMATE){
            cout << "you are examined at the hospital, but have no injuries to speak of\n";
            Sleep(5000);
        }
        if(player.choices[1] == BEATEN){
            cout << "the Knife wound throbs now, but at lease it is now properly treated\n";
                    Sleep(5000);
        }
            cout << "other people who saw the man flee said he had an insignia an his\n"
                    "arm,detailing he worked with and was"
                    "\bbranded by magi who practice forbidden arts, including but not "
                    "limited to enslaving the minds of others\n\n";
            Sleep(5000);
    }
    cout << "now that you were targeted for some reason, you must remain on your\n"
            "guard, other things not so human may come after you as well\n\n";
    Sleep(5000);
    //pointer to set up class for active play
    Character *user;       
    if(player.pClass == HARMONY) user = new Harmony(100,50,10);
    else if(player.pClass == INTROSPECTION) user = new Introspection(100,75,5);
    else user = new Spellbinder(100,50,5);
    //set up encounter
    cout << "as the reality of your situation dawns on you, three unusual enemies\n"
            "arrive to kill you\n\n";
    Sleep(3000);
    //vec to hold initial creatures
    Vec<Ghoul> guys(3);
    guys.push(Ghoul(50,10,20));
    guys.push(Ghoul(50,20,10));
    guys.push(Ghoul(50,10,20));
    bool done = false;          //ends encounter
    bool won = false;           //checks if encounter was survived 
    int spec;                   //holds value increase from special
    do{
        if(guys[0].getHealth() < 1 && guys[1].getHealth() < 1 && guys[2].getHealth() < 1){
            done = true;
            won = true;
            break;
        }
        for(int i = 0; i < 3; i++){
            if(guys[i].getHealth() < 1 ) cout << "ghoul " << i+1 << "dead\n\n";
            
            else {
            guys[i].attack(*user ,guys[i].getStrength());
            }
            if(user->getHealth() < 1){
                done = true;
                won = false;
                break;
            }
        cout << "what will you do?\n\n";
        cout << "A: attack\n";
        if(player.pClass == HARMONY) cout << "B: increase health\n\n";
        else if(player.pClass == INTROSPECTION) cout << "B: increase damage output\n\n";
        else cout << "B: increase Defense value\n\n";
        do{
         cin >> ch;cin.ignore();
    switch(toupper(ch)){
        case 'A':user->attack(guys[i], user->getStrength()); break;
        case 'B':user->special(); break;
        }
        }while(toupper(ch)!= 'A' && toupper(ch) != 'B');
    }
        cout << "your remaining health: " << user->getHealth() << "\n\n";
    }while(done == false);
    //bigger enemy
    cout << "a moment passes, you catch your breath and try to leave the area\n";
    cout << "you do not get far till more strange creatures catch up to you\n"
            "they approach each other and morph into something stranger\n\n";
    Ghoul g1(50,10,20);
    Ghoul g2(50,20,10);
    Fiend fred = g1+g2;
    done = false;
    do{
        if(fred.getHealth() < 1){
            done = true;
            won = true;
            break;
        }
         if(user->getHealth() < 1){
                done = true;
                won = false;
                break;
            }
        if(fred.getHealth() > 49) fred.attack(*user, fred.getStrength());
        
        cout << "what will you do?\n\n";
        cout << "A: attack\n";
        if(player.pClass == HARMONY) cout << "B: increase health\n\n";
        else if(player.pClass == INTROSPECTION) cout << "B: increase damage output\n\n";
        else cout << "B: increase Defense value\n\n";
        do{
         cin >> ch;cin.ignore();
    switch(toupper(ch)){
        case 'A':user->attack(fred, user->getStrength()); break;
        case 'B':user->special(); break;
        }
        }while(toupper(ch)!= 'A' && toupper(ch) != 'B');
        if(fred.getHealth() < 49){
            cout << "the creature seeks to rip a piece of you off\n\n";
            if(user->getDefence() > fred.getStrength()){
                cout << "your defensive skill evades the monster\n";
            }
            else if(user->getStrength() > fred.getDefence()){
                cout << "you take advantage of the creature's desperation and kill\n"
                        "it";
                fred.setHealth(0);
                won = true;
            }
            else if(user->getHealth() > 100){
                cout << "you are too full of pure vitality, the creature gets stunned\n\n";
                user->attack(fred, user->getStrength());
            }
            else{
                cout << "you lose a fraction of your health to the beast, who recovers\n"
                        "with your meat\n\n";
                fred.lifeSteal(*user);
                cout << "your remaining health: " << user->getHealth() << "\n\n";
            }
        }
    }while(done == false);
    if(won == false) "you died\n\n";
    //end of level choice
    else{
        cout << "the creature left a strange artifact on the ground, you do not\n"
                "know what it is, but it has an ominous aura\n\n";
                Sleep(5000);
        cout << "finding out what it is would be beneficial, but it may not be a\n"
                "good idea to keep it on your person, do you take it?\n";
        cout << "A: yes\n";
        cout << "B: no\n";
    }
    do{
        switch(toupper(ch)){
            case 'A': player.choices[2] = TAKE; break;
            case 'B': player.choices[2] = NOT;  break;
        }
        cin >> ch;
    }while(toupper(ch)!= 'A' && toupper(ch) != 'B');
    //deallocate memory
    delete user;
    return player;
}