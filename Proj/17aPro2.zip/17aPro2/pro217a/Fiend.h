/* 
 * File:   Fiend.h
 * Author: Derek Sauri
 */

#ifndef FIEND_H
#define	FIEND_H
#include "Enemy.h"

class Character;

class Fiend: public Enemy {
public:
    Fiend(int,int,int);
    void attack(Character &en, int num);
    void lifeSteal(Character &player);
    Fiend(const Fiend& orig);
    virtual ~Fiend();
private:

};
#endif	/* FIEND_H */