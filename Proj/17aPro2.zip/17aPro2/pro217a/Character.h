/* 
 * File:   Character.h
 * Author: Derek Sauri
 */

#ifndef CHARACTER_H
#define	CHARACTER_H
#include "Fiend.h"
#include "Ghoul.h"
class Character {
public:
    Character();
    virtual void attack(Enemy&, int) = 0;
    virtual void special() = 0;
    void setHealth(int num)
    {this->health = num;};
    void setStrength(int num)
    {this->strength = num;}
    void setDefence(int num)
    {this->defence = num;}
    int getHealth() 
    {return this->health;};
    int getStrength() 
    {return this->strength;};
    int getDefence() 
    {return this->defence;};
    virtual ~Character();
    //friends of class
    friend void Ghoul::attack(Character& en, int num);
    friend void Fiend::lifeSteal(Character& player);
    friend void Fiend::attack(Character& en, int num);
protected:
//values to be inherited
    int health;
    int strength;
    int defence;
    
};
#endif	/* CHARACTER_H */