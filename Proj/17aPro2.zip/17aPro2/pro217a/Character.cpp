/* 
 * File:   Character.cpp
 * Author: Derek
 */

#include "Character.h"

Character::Character() {
    this->defence = 0;
    this->health = 0;
    this->strength = 0;
}
Character::~Character() {
}