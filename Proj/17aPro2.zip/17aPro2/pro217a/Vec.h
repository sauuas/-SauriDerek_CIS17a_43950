/* 
 * File:   Vec.h
 * Author: Derek Sauri
 */

#ifndef VEC_H
#define	VEC_H

using namespace std;
template <class T>
class Vec {
public:
    Vec()
   { aptr = 0; arraySize = 0; endNum = 0;};
   Vec(int);
   Vec(const Vec&);
   T &operator[](const int &);
    int size() const
      { return arraySize; }
    void push(T);
    T getElementAt(int s)
    {return aptr[s];};
    virtual ~Vec();
protected:
   T *aptr;          // To point to the allocated array
   int arraySize;    // Number of elements in the array
   int endNum;       // last unfilled index in array
};
//class functions
template <class T>
Vec<T>::Vec(int s){
     arraySize = s;
     aptr = new T [s];
     //set last index
     endNum = 0;
}
template <class T>
Vec<T>::Vec(const Vec& orig){
    this->arraySize = orig.arraySize;
    
    this->aptr = new T[arraySize];
    
    for(int i = 0; i < arraySize; i++){
        aptr[i] = orig.aptr[i];
    }
}
template <class T>
void Vec<T>::push(T value)
{
    if(endNum < arraySize){
        *(aptr + endNum) = value;
        endNum ++;
    }
    else{
        // New Size
        int newSize;
        if(arraySize == 0) newSize = arraySize+1;
        else newSize = arraySize * 2;
        
        // Allocate memory for the array.
        T* newaptr = new T [newSize];
        // Copy the elements of the old into the new
        for(int count = 0; count < arraySize; count++){
           *(newaptr + count) = *(aptr + count);
        }
        *(newaptr + arraySize)= value;
        //Deallocate and Transfer variables
           delete []aptr;
           aptr=newaptr;
           endNum = arraySize +1;
           arraySize=newSize;
    }
}
template <class T>
Vec<T>::~Vec(){
    if (arraySize > 0)
      delete[] aptr;
}
template <class T>
T &Vec<T>::operator[](const int &sub){
   return aptr[sub];
}
#endif	/* VEC_H */