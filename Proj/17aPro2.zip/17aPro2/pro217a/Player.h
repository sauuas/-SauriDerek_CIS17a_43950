#ifndef PLAYER_H
#define	PLAYER_H
#include <iostream>
#include "Enemy.h"
using namespace std;
//for starter player
struct Player{
    int size;           ///size of string
    char *name;         ///characters name
    int pClass;        ///character class
    int choices[3];   ///important story choices made
};
#endif	/* PLAYER_H */