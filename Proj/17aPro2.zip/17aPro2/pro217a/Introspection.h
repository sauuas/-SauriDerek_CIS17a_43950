/* 
 * File:   Introspection.h
 * Author: derek
 */

#ifndef INTROSPECTION_H
#define	INTROSPECTION_H
#include "Character.h"
#include "Enemy.h"
class Introspection: public Character {
public:
    Introspection();
    Introspection(int, int, int);
    Introspection(const Introspection& orig);
    void attack(Enemy &, int);
    void special();
    virtual ~Introspection();
};
#endif	/* INTROSPECTION_H */