/* 
 * File:   Enums.h
 * Author: Derek Sauri
 */
#ifndef ENUMS_H
#define	ENUMS_H
enum Class{HARMONY, INTROSPECTION, SPELLBINDER}; ///player class choice
enum C1{INDIFFERENT, SUPERIOR, PLAYFUL, ANGRY}; ///opinion of non-mages
enum C2{WON, STALEMATE, BEATEN};                ///outcome of encounter with aggresive person
enum C3{TAKE,NOT};                              //if you took the artifact on the ground
#endif	/* ENUMS_H */