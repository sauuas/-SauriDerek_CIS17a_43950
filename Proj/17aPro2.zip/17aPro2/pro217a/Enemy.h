/* 
 * File:   enemy.h
 * Author: Derek
 */
#ifndef ENEMY_H
#define	ENEMY_H

class Enemy {
public:
    Enemy();
    void setHealth(int num)
    {this->health = num;};
    void setStrength(int num)
    {this->strength = num;}
    void setDefence(int num)
    {this->defence = num;}
    int getHealth()
    {return this->health;};
    int getStrength()
    {return this->strength;};
    int getDefence()
    {return this->defence;};
    Enemy(const Enemy& orig);
    virtual ~Enemy();
protected:
    int health;
    int strength;
    int defence;
};
#endif	/* ENEMY_H */