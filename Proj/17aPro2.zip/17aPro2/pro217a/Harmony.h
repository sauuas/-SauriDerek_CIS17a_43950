/* 
 * File:   Harmony.h
 * Author: derek
 */

#ifndef HARMONY_H
#define	HARMONY_H
#include "Character.h"
#include "Enemy.h"

class Harmony: public Character{
public:
    Harmony();
    Harmony(int, int, int);
    Harmony(const Harmony& orig);
    void attack(Enemy&, int num);
    //make into self heal
    void special();
    virtual ~Harmony();
};
#endif	/* HARMONY_H */