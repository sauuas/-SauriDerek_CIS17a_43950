/* 
 * File:   assignment 3
 * Author: Derek Sauri
 */
#include <iostream>
#include <iomanip>
#include <cstdlib>
#include <fstream>
#include <string>

using namespace std;

//structures
struct MovieData{
    string title;
    string dirNam;
    int year;
    float time;
};
struct MovieData2{
    string title;
    string dirNam;
    int year;
    float time;
    float cost;
    float revenue;
};
struct Speaker{
    string name;
    unsigned int phoneNum;
    string topic;
    int fee;
};
struct Division{
    string name;
    int quarter[4];
    float sale[4];
};

//prototypes
void wordCounter();
int numWord(char*);
void avgNumLet();
float avgLet(char*);
void letCounter();
bool isVowel(char *);
int cntVowel(char *);
int cntCons(char *);
void arFilFun();
void arrayToFile(fstream& ,int *,int);
int *fileToArray(fstream& ,int *,int);
void saleOut();
void movieData();
void movieMod();
void getData(MovieData [], int);
void getData2(MovieData2 [], int);
void display2(MovieData2 [], int);
void getData(MovieData [], int);
void display(MovieData [], int);
void display1(Speaker [], int);
void modElem(Speaker [], int);
void SpeakBe();
void speakIn(Speaker [], int);
void CapStr();
void tenLine();

int main(int argc, char** argv) {
    char choice;
    
    //establish menu
    cout << "choose letter to run program.\n";
    cout << "A: 10.3, B: 10.4, C: 10.6\nD: 11.1, E: 11.2, ";
    cout << "F: 11.9\nG: 12.7,H:12.1, I: 12.8, J: 12.11\n";
    cout << "K: exits the menu\n";
    cout << "choice: "; cin >> choice; cin.ignore();
    do{
    switch(toupper(choice)){
        case 'A': wordCounter();
        break;
        case 'B': avgNumLet();
        break;
        case 'C': letCounter();
        break;
        case 'D': movieData();
        break;
        case 'E': movieMod();
        break;
        case 'F': SpeakBe();
        break;
        case 'G': CapStr();
        break;
        case 'H': tenLine();
        break;
        case 'I': arFilFun();
        break;
         case 'J': saleOut();
        break;
    }
    }while(toupper(choice) != 'K');
    return 0;
}
void wordCounter(){
     char *theString;
    int size = 0;
    
    //get user input
    cout << "input number characters in string plus one.\n";
    cin >> size;
    cin.ignore();
    //size character array
    theString = new char[size];
    cout << "input the string.\n";
    cin.getline(theString, 50);
    //number of words
    int numWords = numWord(theString);
    //display results
    cout << endl << theString << endl;
     cout << "number of words in the c-string: " << numWords << endl;
     //deallocate memory
     delete[] theString;
}
//finds number of words
int numWord(char* a){
    int num = 0;
    while(*(a) != '\0'){
        if(*(a) == ' ' || *(a) == ','){
            num++;
        }
        a++;
    }
    --a;
    if(isalpha(*(a))){
        num++;
    }
    return num;
}
void avgNumLet(){
     char *theString;
    int size = 0;
    
    //get user input
    cout << "input number characters in string plus one.\n";
    cin >> size;
    cin.ignore();
    //size character array
    theString = new char[size];
    cout << "input the string.\n";
    cin.getline(theString, 50);
    //number of words
    int numWords = numWord(theString);
    //average number of letters in the words
    float avg = avgLet(theString);
    
    //display results
    cout << endl << theString << endl;
    cout << "average number of letters in string: " << avg << endl;
     cout << "number of words in the c-string: " << numWords << endl;
     //deallocate memory
     delete[] theString;
}
// gets average number of characters
float avgLet(char* a){
    float avg = 0.0;
    int count = 0;            //holds number of characters per word
    int numword = numWord(a); //gets number of words before pointer manipulation
    
    while(*(a) != '\0'){
        if(isalpha(*(a))){
            count++;
        }
        else if(count != 0){
                avg += count;
                count = 0;
        }
        a++;
    }
    if(count != 0){
                avg += count;
                count = 0;
        }
    avg = avg/numword;
    return avg;
}
void letCounter(){
     char *theString;
    int size = 0;
    int num = 0;
    char choice;
    
    //get user input
    cout << "enter number of characters plus one\n";
    cin >> size;
    while(!cin){
        cin.clear();
        cin.ignore(999,'\n');        
        cout << "invalid input, please enter number of characters plus one\n";
        cin >> size;
    }
     cin.ignore();
    //create dynamic array
    theString = new char[size];
    cout << "input string\n";
    cin.getline(theString, size);
    //menu for user
     do{
    cout << "chose one of the options below\n";
    cout << "A: count vowels in string\n";
    cout << "B: count consonants in string\n";
    cout << "C: count vowels and consonants in string\n";
    cout << "D: enter new string\n";
    cout << "E: exit the program\n";
    cin >> choice;
    switch(toupper(choice)){
        case 'A':num = cntVowel(theString);
        cout <<"number of vowels: " << num <<"\n\n";
        break;
        case 'B':num = cntCons(theString);
        cout <<"number of consonants: " << num <<"\n\n";
        break;
        case 'C':num = cntVowel(theString) + cntCons(theString);
        cout <<"number of letters: " << num <<"\n\n";
        break;
        case'D':delete[] theString;
                cout << "input new string size(plus one)\n";
                    cin >> size; 
                        while(!cin){
                         cin.clear();
                         cin.ignore(999,'\n');        
                         cout << "invalid input, please enter number of characters plus one\n";
                         cin >> size;
                     }
                    cin.ignore();
                     theString = new char[size];
                    cout << "input new string\n";
                    cin.getline(theString, size);
            break;
    }
    }while(toupper(choice) != 'E');
    //deallocate memory
    delete[] theString;
}
//test if character is a vowel
bool isVowel(char *c){
    bool isTrue = false;
        if(toupper(*(c)) == 'A'||toupper(*(c)) == 'E'||toupper(*(c)) == 'I'||
           toupper(*(c)) == 'O'||toupper(*(c)) == 'U'||toupper(*(c)) == 'Y'){
            isTrue = true;
        }
    return isTrue;
}
//count number of vowels
int cntVowel(char *c){
    int num = 0;
    while(*(c) != '\0'){
        if(isalpha(*(c)) && isVowel(c)){
            num ++;
        }
        c++;
    }
        return num;
}
//count number of consonants
int cntCons(char *c){
    int num = 0;
    while(*(c) != '\0'){
        if(isalpha(*(c)) && !isVowel(c)){
            num ++;
        }
        c++;
    }
    return num;
}
void movieData(){
     int size = 2;
    MovieData *a;
    //create array
    a = new MovieData[size];
    //get array values
    getData(a, size);
    //display movie data
    display(a, size);
    //deallocate memory
    delete[] a;
}
//fill array values
void getData(MovieData a[], int size){
    for(int i = 0; i < size; i++){
        cout << "for movie "<< i+1 << endl;
        cout << "input movie title\n";
        getline(cin, a[i].title);
         while(a[i].title.empty()){
            cin.clear();
            cin.ignore(999,'\n');      
            cout << "invalid input, please reenter\n";
            getline(cin, a[i].title);
        }
        cout << "input director's name\n";
        getline(cin, a[i].dirNam);
         while(a[i].dirNam.empty()){
            cin.clear();
            cin.ignore(999,'\n');      
            cout << "invalid input, please reenter\n";
            getline(cin, a[i].dirNam);
        }
        cout << "input release year\n";
        cin >> a[i].year;
         while(cin.fail()|| a[i].year < 0){
             cin.clear();
             cin.ignore(999,'\n');      
            cout << "invalid input, please reenter\n";
            cin >> a[i].year;
        }
        cin.ignore();
        cout << "input movie running time in minutes\n";
        cin >> a[i].time;
         while(cin.fail()|| a[i].time < 0){
             cin.clear();
             cin.ignore(999,'\n');      
            cout << "invalid input, please reenter\n";
            cin >> a[i].time;
        }
        cin.ignore();
    }
}
//formats and displays movie data
void display(MovieData a[], int size){
    cout << fixed << showpoint << setprecision(2) << endl;
    for(int i = 0; i < size; i++){
        cout << setw(25) << "for movie " << i + 1 << endl;
        cout << setw(25) << "movie title " << a[i].title << endl; 
        cout << setw(25) << "director name " << a[i].dirNam << endl;
        cout << setw(25) << "release year " << a[i].year << endl;
        cout << setw(25) << "running time " << a[i].time << "\n\n";
    }
}
void movieMod(){
    int size = 2;
    MovieData2 *a;
    //create array
    a = new MovieData2[size];
    //get array values
    getData2(a, size);
    //display movie data
    display2(a, size);
    //deallocate memory
    delete[] a;
}
//fill array values
void getData2(MovieData2 a[], int size){
    for(int i = 0; i < size; i++){
        cout << "for movie "<< i+1 << endl;
        cout << "input movie title\n";
        getline(cin, a[i].title);
         while(a[i].title.empty()){
            cin.clear();
            cin.ignore(999,'\n');      
            cout << "invalid input, please reenter\n";
            getline(cin, a[i].title);
        }
        cout << "input director's name\n";
        getline(cin, a[i].dirNam);
         while(a[i].dirNam.empty()){
            cin.clear();
            cin.ignore(999,'\n');      
            cout << "invalid input, please reenter\n";
            getline(cin, a[i].dirNam);
        }
        cout << "input release year\n";
        cin >> a[i].year;
         while(cin.fail()|| a[i].year < 0){
             cin.clear();
             cin.ignore(999,'\n');      
            cout << "invalid input, please reenter\n";
            cin >> a[i].year;
        }
        cin.ignore();
        cout << "input movie running time in minutes\n";
        cin >> a[i].time;
         while(cin.fail()|| a[i].time < 0){
             cin.clear();
             cin.ignore(999,'\n');      
            cout << "invalid input, please reenter\n";
            cin >> a[i].time;
        }
        cin.ignore();
        cout << "input movie production cost\n";
        cin >> a[i].cost;
        while(cin.fail()|| a[i].cost < 0){
             cin.clear();
             cin.ignore(999,'\n');      
            cout << "invalid input, please reenter\n";
            cin >> a[i].cost;
        }
        cin.ignore();
         cout << "input movie first year revenue\n";
        cin >> a[i].revenue;
        while(cin.fail()|| a[i].revenue < 0){
             cin.clear();
             cin.ignore(999,'\n');      
            cout << "invalid input, please reenter\n";
            cin >> a[i].revenue;
        }
        cin.ignore();
    }
}
//formats and displays movie data
void display2(MovieData2 a[], int size){
    cout << fixed << showpoint << setprecision(2) << endl;
    for(int i = 0; i < size; i++){
        cout << setw(30) << "for movie " << i + 1 << endl;
        cout << setw(30) << "movie title " << a[i].title << endl; 
        cout << setw(30) << "director name " << a[i].dirNam << endl;
        cout << setw(30) << "release year " << a[i].year << endl;
        cout << setw(30) << "running time " << a[i].time << endl;
        if((a[i].revenue - a[i].cost)<0)cout << setw(30) << "first year loss " << (a[i].revenue - a[i].cost) << "\n\n";
        else cout << setw(30) << "first year profit " << (a[i].revenue - a[i].cost) << "\n\n";
    }
}
void SpeakBe(){
     int size;   //size of array
    Speaker *a; //array holder
    char choice;
    
    //get number of speakers
        cout << "enter number of speakers.\n";
        cin >> size; cin.ignore();
    //create array
    a = new Speaker[size];
    //get initial speaker information
    speakIn(a, size);
    //display
    display1(a, size);
    //menu
    do{
    cout << "what do you wish to do?\n";
    cout << "A: enter data into entire array\n";
    cout << "B: change a specific element of a speaker\n";
    cout << "C: display all speakers information\n";
    cout << "E: exit program\n";
    cin >> choice;
    
    switch(toupper(choice)){
        case 'A':speakIn(a, size);
        break;
        case'B':modElem(a, size);
        break;
        case'C':display1(a, size);
        break;
        case'E':cout << "exit adjacent stage\n";
        break;
        default:cout << "if you want to exit, press e,\n otherwise pick a valid option\n";
    }
    }while(toupper(choice) != 'E');
    //deallocate memory
    delete[] a;
}
//get all speaker information
void speakIn(Speaker a[], int size){
    //get information of speakers
    for(int i = 0; i < size; i++){
        cout << "enter Speaker " << i +1 << "'s name\n";
        getline(cin, a[i].name);
        while(a[i].name.empty()){
            cin.clear();
            cin.ignore(999,'\n');     
            cout << "invalid input, please reenter\n";
            getline(cin, a[i].name);
        }
         cout << "enter Speaker " << i +1 << "'s phone number\n";
         cin >> a[i].phoneNum;
        while(cin.fail() || a[i].phoneNum < 1000000){
            cout << "invalid input, please reenter\n";
            cin >> a[i].phoneNum;
        }
        cin.ignore();
         cout << "enter Speaker " << i +1 << "'s topic\n";
        getline(cin, a[i].topic); 
        while(a[i].topic.empty()){
            cin.clear();
            cin.ignore(999,'\n');      
            cout << "invalid input, please reenter\n";
            getline(cin, a[i].topic);
        }
         cout << "enter Speaker " << i +1 << "'s fee\n";
        cin >> a[i].fee; 
         while(cin.fail()|| a[i].fee < 0){
             cin.clear();
             cin.ignore(999,'\n');      
            cout << "invalid input, please reenter\n";
            cin >> a[i].fee;
        }
        cin.ignore();
    }
}
 //display speaker information
void display1(Speaker a[], int size){
    for(int i = 0; i < size; i++){
        cout << "Speaker       " << i + 1 << endl;
        cout << "name          " << a[i].name << endl;
        cout << "phone number  " << a[i].phoneNum << endl;
        cout << "topic         " << a[i].topic << endl;
        cout << "fee for view $" << a[i].fee << "\n\n";
    }
}
//change element of a speaker
void modElem(Speaker a[], int size){
    int num = 0;
    char choice;
    do{
    cout << "enter speaker number to modify(must be speaker number in list)\n";
    cin >> num; cin.ignore();
    }while(num > size || num < 0);
    //pick element to modify
    cout << "what do you wish to change of speaker " << num << endl;
    cout << "a: name\n";
    cout << "b: phone number\n";
    cout << "c: topic\n";
    cout << "d: fee\n";
    cin >> choice; cin.ignore();
    switch(toupper(choice)){
        case 'A': cout << "enter Speaker " << num << "'s name\n";
        getline(cin, a[num-1].name);
        while(a[num-1].name.empty()){
            cin.clear();
            cin.ignore(999,'\n');     
            cout << "invalid input, please reenter\n";
            getline(cin, a[num-1].name);
        }
        break;
        case 'B': cout << "enter Speaker " << num << "'s phone number\n";
         cin >> a[num-1].phoneNum;cin.ignore();
        while(cin.fail() || a[num-1].phoneNum < 1000000){
            cout << "invalid input, please reenter\n";
            cin >> a[num-1].phoneNum;
        }
         break;
        case 'C':    cout << "enter Speaker " << num << "'s topic\n";
        getline(cin, a[num-1].topic); 
        while(a[num-1].topic.empty()){
            cin.clear();
            cin.ignore(999,'\n');      
            cout << "invalid input, please reenter\n";
            getline(cin, a[num-1].topic);
        }
        break;
        case 'D':   cout << "enter Speaker " << num << "'s fee\n";
        cin >> a[num-1].fee; cin.ignore();
         while(cin.fail()|| a[num-1].fee < 0){
             cin.clear();
             cin.ignore(999,'\n');      
            cout << "invalid input, please reenter\n";
            cin >> a[num-1].fee;
        }
        break;
        default: cout << "no valid choice is selected\n";
    }
}
void CapStr(){
    ifstream input;
    ofstream output;
    string inFile;
    string outFile;
    char ch;
    
    // get file with information
    cout << "enter file to read from\n";
    cin >> inFile; cin.ignore();
    // get file for output
    cout << "enter file for output\n";
    cin >> outFile;
    
    //open files
    input.open(inFile.c_str());
    output.open(outFile.c_str());
    
    if(input){
        input.get(ch);
        bool first = true;  // checks if character is first in sentence
        
        while(input){
            if(first == true){
            output.put(toupper(ch));
            first = false;
            }
            else output.put(tolower(ch));
            
            input.get(ch);
            //'.' marks end of sentence
            if(ch == '.'){
            first = true;
            output.put(ch);
            input.get(ch);
            }
        }
    }
    else cout << "cannot open input file.\n";
    
    //close files
    input.close();
    output.close();
}
void arFilFun(){
    fstream file;
    int *a;
    int size = 5;
    int array[size] = {1,2,3,4,5};
    int *output;
    
    a = array;
    //write elements to a file
    arrayToFile(file, array, size);
    output =fileToArray(file, a, size);
    //display output
    for(int i = 0; i < size; i++){
        cout << *(output + i) << endl;
    }
}
void arrayToFile(fstream& file,int *a,int size){
    //open the file
    file.open("thisFile.dat", ios::out | ios::binary);
    file.write(reinterpret_cast<char *>(a), sizeof(a));
    //close the file
    file.close();
}
int *fileToArray(fstream& file,int *a,int size){
    
    //open the file
    file.open("thisFile.dat",ios::in | ios::binary);
    file.read(reinterpret_cast<char *>(a), sizeof(a));
    
    //close the file
    file.close();
    return a;
}
void saleOut(){
    Division company[4];
    fstream file;
    
    //initialize the four divisions
    company[0].name = "East";
    company[1].name = "West";
    company[2].name = "North";
    company[3].name = "South";
    //get input per quarter
    for(int i = 0; i < 4; i++){
        cout << "division " << company[i].name << endl;
        for(int j = 0; j < 4; j++){
            company[i].quarter[j] = j + 1;
            cout << "input sales for quarter " << company[i].quarter[j] << endl;
            cin >> company[i].sale[j];
        }
    }
    //write to file
    file.open("companyDivision.dat", ios::out | ios::binary);
    file.write(reinterpret_cast<char *>(&company), sizeof(company));
    //close the file
    file.close();
}
void tenLine(){
     fstream file;
    string name;
    string input;
    int count;
    
    //ask for file name
    cout << "input file name\n";
    getline(cin, name);
    if(file){
        //retrieve data from file
        file.open(name.c_str(),ios::in);
        getline(file, input);
        while(file){
            if(count >= 10)break;
            cout << input << endl;
            getline(file, input);
            count++;
        }
    }
    else{
        cout << "error occurred in file inputed\n";
    }
}