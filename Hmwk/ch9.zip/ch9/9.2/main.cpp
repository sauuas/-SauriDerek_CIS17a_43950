/* 
 * Test scores
 * Author: Derek Sauri
 */

#include <iostream>

using namespace std;

// prototypes
int* getScore(int);
void srtAray(int[],int);
float getAvg(int[], int);

int main() {
    int numScores = 0;
    int* test;
    float avg = 0.0;
    //make sure number of test scores is not negative
    do{
    cout << "how many test scores do you wish to enter?(number cannot be negative)\n";
    cin >> numScores;
    }while(numScores < 0);
    //if no test scores
    if(numScores == 0){
        cout << "no test scores\n";
        return 0;
    }
    //create array to hold the test scores
    test = new int[numScores];
    //prompt user for scores
    test = getScore(numScores);
    // sort the scores
    srtAray(test, numScores);
    //find test average
    avg = getAvg(test, numScores);
    // display results
    cout << "test scores in ascending order\n";
    for(int i = 0;i < numScores; i++){
        cout << test[i] << " ";
    }
    cout << endl << "test average is " << avg << endl;
    // release allocated memory
    delete[] test;
    return 0;
}
int* getScore(int num){
    int* a;
    a = new int[num];
    for(int i = 0;i < num; i++){
        do{
        cout << "score for test(score cannot be negative) " << i+1 << endl;
        cin >> a[i];
        }while(a[i] < 0);
        cout << endl;
    }
    return a;
    
}
void srtAray(int a[], int asize){
    for (int i = 0; i < asize; i++){
        int small = i;
        int temp;
        for(int j = i;j < asize; j++){
            if(a[j] < a[small])
                small = j;
        }
        temp = a[i];
        a[i]= a[small];
        a[small] = temp;
    }
}
float getAvg(int a[], int asize){
     float avg = 0.0;
    
    for(int i = 0;i < asize; i++){
        avg+= a[i];
    }
    avg/= asize;
    return avg;
}

