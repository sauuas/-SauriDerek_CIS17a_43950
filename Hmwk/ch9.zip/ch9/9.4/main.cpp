/* 
 * Test scores #2
 * Author: Derek Sauri
 * build fails if sort is implemented
 */

#include <iostream>

using namespace std;

//abstract data type
struct student{
    string name;
    int score;
};

// prototypes
void getScore(student*,int);
int* srtAray(student*,int);
float getAvg(student*, int);



int main() {
    int numScores = 0;
    student* test;
    int* in;    //allows me to sort array without changing original reference
    float avg = 0.0;
    //make sure number of test scores is not negative
    do{
    cout << "how many test scores do you wish to enter?(number cannot be negative)\n";
    cin >> numScores;
    }while(numScores < 0);
    //if no test scores
    if(numScores == 0){
        cout << "no test scores\n";
        return 0;
    }
    //create array to hold names and test scores
    test = new student[numScores];
    //prompt user for name and score
     getScore(test,numScores);
    // sort the scores
   // in = srtAray(test, numScores);
    //find test average
    avg = getAvg(test, numScores);
    // display results
    cout << "student with test score\n";
    for(int i = 0;i < numScores; i++){
        cout << "name " << (test + i)->name << " ";
        cout << "test score " << (test+ i)->score  << endl;
    }
    cout << endl << "test average is " << avg << endl;
    // release allocated memory
    delete[] test;
    return 0;
}
void getScore(student* you,int num){
    
    for(int i = 0;i < num; i++){
        cout << "enter name\n";
        cin >> (you + i)->name;
        do{
        cout << "score for test(score must be between 0 and 100) " << i+1 << endl;
        cin >> (you + i)->score;
        }while((you + i)->score < 0 ||(you + i)->score > 100 );
        cout << endl;
    }
    
}
/* do not know what is wrong with the sort 
int* srtAray(student* a, int asize){
    int* in = new int[asize];
    for(int i =0;i<asize;i++){
        *in = i;
        in++;
    }
    for (*in; *in < asize; in++){
        int small = *in;
        int temp;
        for(int j = *in;j < asize; j++){
            if((a + j)->score < (a + small)->score)
                small = j;
        }
        temp = *(in+ *(in));
        *(in+*(in))= small;
        *(in + small)= temp;
    }
    return in;
} 
 * */
float getAvg(student* a, int asize){
     float avg = 0.0;
    
    for(int i = 0;i < asize; i++){
        avg+= (a + i)->score;
    }
    avg/= asize;
    return avg;
}

