/* Dynamic array practice 
 * Derek Sauri
 */

#include <iostream>
#include <iomanip>
#include <cstdlib>
#include <ctime>

using namespace std;

// prototypes
void fillArray(int[], int);
void sortArray(int[], int);
void printArray(int[], int);
float fndMean(int[], int);
float fndMid(int[], int);
void numModes(int[],int, int& ,int&);
void fillDynA(int[], int[], int, int&);
void prtReslt(int[], float, float);

/*
 * find the mode in the given array and create a dynamic array to store contents
 */
int main() {
    const int ARRAY_SIZE = 20;
    float mean = 0.0;
    float median = 0.0;
    int feq = 0;
    int numMode= 0;
    int *dynA;
    int a[ARRAY_SIZE];
    
    // create array filled with random digits
    fillArray(a, ARRAY_SIZE);
    sortArray(a, ARRAY_SIZE);
    printArray(a, ARRAY_SIZE);
    // find the mean
    mean = fndMean(a, ARRAY_SIZE);
    // find the median
    median = fndMid(a, ARRAY_SIZE);
    // find the number of modes and the highest frequency
    numModes(a,ARRAY_SIZE,numMode, feq);
    // if no mode
    if (feq < 2){
        cout << "there is no mode.\n";
        return 0;
    }
    
    dynA = new int[numMode + 2];
    dynA[0] = numMode;
    dynA[1] = feq;
    //fill all the modes from the previous array
    fillDynA(dynA, a, ARRAY_SIZE, feq);
    //display results
    prtReslt(dynA, mean, median);
    delete [] dynA;
    return 0;
}
void fillArray(int a[],int asize){
    srand(time(0));
    
    for(int i = 0; i < asize; i++){
        a[i] = rand() % 11;
    }
}
void sortArray(int a[],int asize){
    for (int i = 0; i < asize; i++){
        int small = i;
        int temp;
        for(int j = i;j < asize; j++){
            if(a[j] < a[small])
                small = j;
        }
        temp = a[i];
        a[i]= a[small];
        a[small] = temp;
    }
}
void printArray(int a[],int asize){
    for (int i = 0;i < asize; i++){
        cout << a[i] << " ";
    }
    cout << endl;
}
float fndMean(int a[],int ARRAY_SIZE){
    float mean = 0.0;
    
    for(int i = 0;i < ARRAY_SIZE; i++){
        mean+= a[i];
    }
    mean/= ARRAY_SIZE;
    return mean;
}
float fndMid(int a[], int ARRAY_SIZE){
    float median = 0.0;
    
    if((ARRAY_SIZE%2)==0){
        median = (a[ARRAY_SIZE/2]+a[(ARRAY_SIZE/2)-1])/2;
    }
    else if((ARRAY_SIZE%2)!=0){
        median = a[(ARRAY_SIZE/2)-1];
    }
    return median;
}
void numModes(int a[],int ARRAY_SIZE,int &numMode,int &feq){
    int temp = a[0];
    int count= 0;
    int max = 0;
    // find highest frequency
        for (int i =0;i < ARRAY_SIZE;i++){
            if (a[i]== temp){
                count++;
            }
            else if(a[i] != temp){
                    if (count > max){
                        max = count;
                    }
                temp = a[i];
                count = 1;
            }
        }
    if (count > max){
         max = count;
     }
     feq = max;
     // find number of modes
     temp = a[0];
     count = 0;
    for (int i =0;i < ARRAY_SIZE;i++){
            if (a[i]== temp){
                count++;
            }
            else if(a[i] != temp){
                if (count == max){
                    numMode++;
                }
                temp = a[i];
                count = 1;
            }
        }
     if (count == max){
         numMode++;
        }
}
void fillDynA(int dynA[], int a[], int aSize, int &feq){
    int temp = a[0];
    int count= 0;
    int i = 2;
        
            for (int j =0;j < aSize;j++){
                if (a[j]== temp){
                    count++;
                }
                else if(a[j] != temp){
                    if (count == feq){
                        dynA[i] = temp;
                        i++;
                    }
                    temp = a[j];
                    count = 1;
                   }  
            }
    if (count == feq){
        dynA[i] = temp;
     }
}
void prtReslt(int a[], float mean, float median){
    cout << fixed << showpoint << setprecision(1);
    cout << "the mean of the array is " << mean << endl;
    cout << "the median of the array is " << median << endl;
    cout << "the number of modes is " << a[0] << endl;
    cout << "the highest frequency is " << a[1] << endl;
    for (int i = 2;i < a[0]+2; i++){
        cout << a[i] << " ";
    }
    cout << endl;
}
