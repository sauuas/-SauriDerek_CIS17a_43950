/* 
 * case study mod #1
 * Author: Derek Sauri
 */

#include <iostream>

using namespace std;

//prototypes
int *getDon(int);
void srtAray(int[],int);
void printArray(int[], int);

int main() {
   int numDon = 0;      //number of donations
   int *donation;
   int *aPtr;
   
   //find out how many donations there will be
   do{
   cout << "how many donations will be received?(cannot be less than 0)\n";
   cin >> numDon;
   }while(numDon < 0);
   //create array to hold donation amounts
   donation = new int[numDon];
   // get donation amounts
   donation = getDon(numDon);
   aPtr = new int[numDon];
   //set donation and pointer values the same
   for(int i = 0; i < numDon; i++){
       aPtr[i] = donation[i];
   }
   //sort pointer array
   srtAray(aPtr, numDon);
   //print arrays to show difference
   cout << "donations array\n";
   printArray(donation, numDon);
   cout << "pointer array\n";
   printArray(aPtr, numDon);
   //release memory
   delete[] aPtr;
   delete[] donation;
   
    return 0;
}
int* getDon(int num){
    int* a;
    a = new int[num];
    for(int i = 0;i < num; i++){
        do{
        cout << "input donation amount(cannot be negative) " << i+1 << endl;
        cin >> a[i];
        }while(a[i] < 0);
        cout << endl;
    }
    return a;
    
}
void srtAray(int a[], int asize){
    for (int i = 0; i < asize; i++){
        int small = i;
        int temp;
        for(int j = i;j < asize; j++){
            if(a[j] < a[small])
                small = j;
        }
        temp = a[i];
        a[i]= a[small];
        a[small] = temp;
    }
}
void printArray(int a[],int asize){
    for (int i = 1;i <= asize; i++){
        cout << a[i-1] << " ";
        if(i%10==0) cout << endl;
    }
    cout << endl;
}
