/* 
 * string binary search
 * Derek Sauri
 */

#include <iostream>
#include <string>

using namespace std;

// prototypes
void sortArr(string[], int size);
void binSearch(string[], string, int size);

int main() {
 string name;
 string aName[] = {"Collins, Bill", "Smith, Bart", "Allen, Jim","Griffin, Jim", "Stamey, Marty", "Rose, Geri",
 "Taylor, Terri", "Johnson, Jill","Allison, Jeff", "Looney, Joe", "Wolfe, Bill", "James, Jean", "Weaver, Jim", "Pore, Bob",
 "Rutherford, Greg", "Javens, Renee","Harrison, Rose", "Setzer, Cathy","Pike, Gordon", "Holland, Beth" };
 int size = 6;
 
 // sort the array
 sortArr(aName, size);
 
 cout << "what is name you are searching for?\n";
 getline(cin, name);
 
 //binary search for name
 binSearch(aName, name, size);
    return 0;
}
void sortArr(string a[], int asize){
     for (int i = 0; i < asize; i++){
        int small = i;
        string temp;
        for(int j = i;j < asize; j++){
            if(a[j] < a[small])
                small = j;
        }
        temp = a[i];
        a[i]= a[small];
        a[small] = temp;
    }
     
     // debugging
     for (int i = 0; i < asize; i++){
         cout << a[i] << " ";
     }
     cout << endl;
    
}
void binSearch(string a[], string name, int size)
{
	int first = 0;
	int last = size-1;
	int middle;
	int position = -1;
	bool found = false; 
	do{
		middle = (first + last)/2;
		if(a[middle] == name){
			found = true;
			position = middle;
		}
		else if (a[middle] > name){
			last = middle;
		}
		else{
			first = middle;
		}
	}while(!found && first <last);
        if(position == -1){
            cout << "name not found\n";
        }
        else{
          cout << name<< " at position: " << position + 1 << endl;
        }
}

