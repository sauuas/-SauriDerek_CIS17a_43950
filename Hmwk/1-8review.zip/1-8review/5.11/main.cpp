/* 
 * Population
 * Author: Derek Sauri
 */

#include <iostream>

using namespace std;

int main() {
    int pop;        //holds population value 
    float popAvg;   //percent increase
    int days;       //days population increase
    
    // get population
    do{
    cout << "what is the starting population?(cannot be less than 2)\n";
    cin >> pop;
    }while(pop < 2);
    //get growth rate as a percent
    do{
    cout << "what is the population growth percentage?(cannot be negative)\n";
    cin >> popAvg;
    }while(popAvg < 0);
    popAvg /= 100;
    //get number of days
    do{
    cout << "how many days does the population grow?(cannot be less than 1)\n";
    cin >> days;
    }while(days < 1);
    // display population growth per day
    for(int i = 1;i <= days; i++){
        cout << "day "<< i << endl;
        cout << "population size: " << pop << endl;
        pop += pop * popAvg;
    }

    return 0;
}

