/* Derek Sauri
Monthly sales tax
        */
#include <iostream>
#include <string>
#include <iomanip>

using namespace std;

//prototypes
bool isValidMth(string);

int main()
{
    // month, year, and total money collected established
    string month;
    short year;
    float total;

    // getting value for month and year
    cout << "input full month\n";
    getline(cin, month);
    cin.ignore();
     // getting value for year
    do{
    cout << "input year between 0 and 2015\n";
    cin >>  year;
    }while(year > 2015 && year < 0);
        
    // getting total income collected in month
    cout << "how much money was collected this month?\n";
    cin >> total;
    
    // display month, year,country and sate and total taxes, sales, and total collected
    
    cout << "In the month of " << month << ": " << year << endl;
    cout << "--------------------------------------------------" << endl;
    cout << fixed << showpoint << setprecision(2);
    cout  << right << setw(20) << "total collected: $" << " " << total*1.06 << endl;
    cout  << right << setw(20) << "sales: $"   << " " << total << endl;
    cout  << right << setw(20) << "sales tax: $"   << " " << total*0.06 << endl;
    cout  << right << setw(20) << "state tax: $"   << " " << total*0.04 << endl;
    cout  << right << setw(20) << "county tax: $"   << " " << total*0.02 << endl;
   return 0; 
}
