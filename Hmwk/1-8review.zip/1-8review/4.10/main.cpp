/* 
 * software sales
 * Author: Derek Sauri
 */

#include <iostream>
#include <iomanip>

using namespace std;

//prototypes
float checkDis(int);

int main() {
    int sale;   //units bought
    float cost; //cost of units
    
    //get number of units sold
    do{
    cout << "how many units of software do you wish to buy?(cannot be less than 1)\n";
    cin >> sale;
    }while(sale < 1);
    // find which discount applies to number of units sold
    cost = checkDis(sale);
    
    // display results
    cout << fixed << showpoint << setprecision(2);
    cout << "cost of package is " << cost << endl;
    return 0;
}
float checkDis(int sale){
    float num;
    
    if(static_cast<float>(sale) < 10){
        num = static_cast<float>(sale)*99;
    }
    else if(sale < 20){
        num = ((static_cast<float>(sale)*99)*20)/100;
    }
    else if(sale < 50){
        num = ((static_cast<float>(sale)*99)*30)/100;
    }
    else if(sale < 100){
        num = ((static_cast<float>(sale)*99)*40)/100;
    }
    else if(sale >= 100){
        num = ((static_cast<float>(sale)*99)*50)/100;
    }
    return num;
}
