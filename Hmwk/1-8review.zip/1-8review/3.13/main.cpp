/* 
 * property tax
 * Author: Derek Sauri
 */
#include <iostream>
#include <iomanip>

using namespace std;

// ask for real value of property, calculate assessed property value(60%) and tax
// tax is 64 cents per 100$

// prototypes
float getValue();
void calcTax(float);

int main() {
    float realVal = 0;
    realVal = getValue();
    calcTax(realVal);
    
    return 0;
}

// get real property value
float getValue(){
    float real;
    cout << "get is the real value of the property?\n";
    cin >> real;
    
    return real;
}
//calculate assessed value, taxes on assessed value, display results
void calcTax(float real){
    float assessed = (real*60.0)/100.0;
    
    cout << fixed << showpoint << setprecision(2);
    cout << "property value:  " << assessed<< endl;
    cout << "tax on property: "<< (assessed/100) *.64 << endl;
}