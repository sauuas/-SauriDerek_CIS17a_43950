/* 
 * Number analysis 
 * Author: Derek Sauri
 * cannot find way to properly receive file name and then search for it. 
 */

#include <fstream>
#include <iostream>
#include <iomanip>
#include <string>

using namespace std;

//prototypes
int sizeArr(ifstream&, string);
void fillArray(ifstream&, string, int[]);
void anaDisNum(int[], int);

int main() {
    ifstream inFile;
    string name;
    int* array;
    int size;
    
    cout << "input file name.\n";
    getline(cin, name);
    cin.ignore();
    
    if (!inFile){
        cout << "file not found\n";
        return 0;
    }
    
    // find number of elements to initialize array
    size = sizeArr(inFile, name);
    if (size < 1){
        cout << "there is an error.\n";
        return 0;
    }
    array = new int[size];
    
    // fill in the array
    fillArray(inFile, name, array);
    
    // analyze, and display elements
    anaDisNum(array, size);

    return 0;
}

//determine number of variables
int sizeArr(ifstream& inFile, string name){
    int num = 0;
    
    inFile.open(name.c_str());
    while(inFile){
        num++;
    }
    inFile.close();
    return num;
}

// fill array
void fillArray(ifstream& inFile,string name, int a[]){
    int i = 0;
    inFile.open(name.c_str());
    while(inFile){
        cin >> a[i];
        i++;
    }
    inFile.close();
    
}

// find lowest, highest, sum, and average of numbers and display them
void anaDisNum(int a[], int size){
    int low= a[0];
    int high= a[0];
    float total= 0.0;
    
    for(int i = 0; i < size; i++){
        if(low > a[i]){
            low = a[i];
        }
        if(high < a[i]){
            high = a[i];
        }
        total += a[i];
    }
    
    cout << fixed << showpoint << setprecision(2);
    cout << "the lowest number is:        " << low << endl;
    cout << "the highest number is:       " << high << endl;
    cout << "the total of the numbers is: " << total << endl;
    cout << "the average number is:       " << total/size << endl;
}

