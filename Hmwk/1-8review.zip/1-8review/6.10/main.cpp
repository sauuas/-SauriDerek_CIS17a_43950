/* 
 * Lowest score drop
 * Author: Derek Sauri
 */

#include <iomanip>
#include <iostream>

using namespace std;

//prototypes
void getScore(int[]);
void calcAvg(int[]);
int findLow(int[]);

int main() {
    int  a[5];
    //get scores from user
    getScore(a);
    //calculate test average, will also drop lowest test score
    calcAvg(a);
    
    return 0;
}
void getScore(int a[]){
    
    for (int i = 0; i < 5; i ++){
            do{
            cout << "input score(cannot be less than zero or greater than 100)\n";
            cin >> a[i];
            }while(a[i] < 0 || a[i] > 100);
    }
    
}
void calcAvg(int a[]){
    //find the lowest test score
    int low = findLow(a);
    if (low == -1){
        cout<<"there is an error.\n";
    }
    float avg;
        for(int i = 0; i < 5; i++){
                if(i != low){
                    avg+=a[i];
                }
    }
    avg = avg/4;
    cout << fixed << showpoint << setprecision(2);
    cout << "test average is " << avg << endl;
    
}
int findLow(int a[]){
    int low = a[0];    // holds lowest value
    int in = -1;    // holds location of lowest value
        for (int i = 0; i < 5; i ++){
            if(a[i]< low){
                low = a[i];
                in = i;
            }
        }
    cout << "Lowest score is number: " << in + 1 <<endl;
    return in;
}

