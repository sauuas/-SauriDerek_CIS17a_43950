/* 
 * word counter
 * Author: Derek Sauri
 */
#include <iostream>


using namespace std;

//prototypes
int numWord(char*);

int main() {
    char *theString;
    int size = 0;
    
    //get user input
    cout << "input number characters in string plus one.\n";
    cin >> size;
    cin.ignore();
    //size character array
    theString = new char[size];
    cout << "input the string.\n";
    cin.getline(theString, 50);
    //number of words
    int numWords = numWord(theString);
    //display results
    cout << endl << theString << endl;
     cout << "number of words in the c-string: " << numWords << endl;
     //deallocate memory
     delete[] theString;
    return 0;
}
//finds number of words
int numWord(char* a){
    int num = 0;
    while(*(a) != '\0'){
        if(*(a) == ' ' || *(a) == ','){
            num++;
        }
        a++;
    }
    --a;
    if(isalpha(*(a))){
        num++;
    }
    return num;
}