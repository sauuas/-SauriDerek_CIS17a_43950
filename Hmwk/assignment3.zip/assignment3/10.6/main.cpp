/* 
 * 10.6 vowel and consonant counter
 * Author: Derek Sauri
 */

#include <iostream>

using namespace std;

//prototypes
bool isVowel(char *);
int cntVowel(char *);
int cntCons(char *);

int main() {
    char *theString;
    int size = 0;
    int num = 0;
    char choice;
    
    //get user input
    cout << "enter number of characters plus one\n";
    cin >> size;
    cin.ignore();
    //create dynamic array
    theString = new char[size];
    cout << "input string\n";
    cin.getline(theString, size);
    //menu for user
     do{
    cout << "chose one of the options below\n";
    cout << "A: count vowels in string\n";
    cout << "B: count consonants in string\n";
    cout << "C: count vowels and consonants in string\n";
    cout << "D: enter new string\n";
    cout << "E: exit the program\n";
    cin >> choice;
    switch(toupper(choice)){
        case 'A':num = cntVowel(theString);
        cout <<"number of vowels: " << num <<endl;
        cout <<"to exit, press E, any other key returns menu\n";
        cin >> choice;
        break;
        case 'B':num = cntCons(theString);
        cout <<"number of consonants: " << num <<endl;
        cout <<"to exit, press E, any other key returns menu\n";
        cin >> choice;
        break;
        case 'C':num = cntVowel(theString) + cntCons(theString);
        cout <<"number of letters: " << num <<endl;
        cout <<"to exit, press E, any other key returns menu\n";
        cin >> choice;
        break;
        case'D':cout << "input new string size(plus one)\n";
                cin >> size; cin.ignore();
                 theString = new char[size];
                cout << "input new string\n";
                cin.getline(theString, size);
        break;
    }
     //deallocate memory
    delete[] theString;
    }while(toupper(choice) != 'E');
    
    return 0;
}
//test if character is a vowel
bool isVowel(char *c){
    bool isTrue = false;
        if(toupper(*(c)) == 'A'||toupper(*(c)) == 'E'||toupper(*(c)) == 'I'||
           toupper(*(c)) == 'O'||toupper(*(c)) == 'U'||toupper(*(c)) == 'Y'){
            isTrue = true;
        }
    return isTrue;
}
//count number of vowels
int cntVowel(char *c){
    int num = 0;
    while(*(c) != '\0'){
        if(isalpha(*(c)) && isVowel(c)){
            num ++;
        }
        c++;
    }
        return num;
}
//count number of consonants
int cntCons(char *c){
    int num = 0;
    while(*(c) != '\0'){
        if(isalpha(*(c)) && !isVowel(c)){
            num ++;
        }
        c++;
    }
    return num;
}