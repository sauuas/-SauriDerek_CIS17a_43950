/* 
 * File:   day of year mod
 * Author: Derek Sauri
 */

#include <iostream>
#include <string>

#include "DayOfYear.h"

using namespace std;

/*
 * 
 */
int main() {
    DayOfYear a("December",31);
    a.print();
    a++;
    a.print();
    a--;
    a.print();

    return 0;
}

