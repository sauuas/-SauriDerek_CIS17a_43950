/* 
 * File:   DayOfYear.h
 * Author: Derek
 */

#ifndef DAYOFYEAR_H
#define	DAYOFYEAR_H

#include <string>

using namespace std;

class DayOfYear {
public:
    DayOfYear(int);
    DayOfYear(string, int);
   void print();
   DayOfYear operator ++();
   DayOfYear operator ++(int);
   DayOfYear operator --();
   DayOfYear operator --(int);
    virtual ~DayOfYear();
private:
    string month;
    int day;

};

#endif	/* DAYOFYEAR_H */

