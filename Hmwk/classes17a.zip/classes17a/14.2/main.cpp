/* 
 * File:   day of year
 * Author: Derek Sauri
 */

#include <iostream>

#include "DayOfYear.h"

using namespace std;

/*
 * 
 */
int main() {
    DayOfYear a(47),b(31),c(333);
    a.print();
    b.print();
    c.print();
    
    return 0;
}

