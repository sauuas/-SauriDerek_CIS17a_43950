/* 
 * File:   DayOfYear.h
 * Author: Derek
 */

#ifndef DAYOFYEAR_H
#define	DAYOFYEAR_H


class DayOfYear {
public:
    DayOfYear(int);
   void print();
    virtual ~DayOfYear();
private:
    int day;

};

#endif	/* DAYOFYEAR_H */

