/* 
 * File:   TimeOff.cpp
 * Author: Derek
 */

#include "TimeOff.h"

TimeOff::TimeOff(string name, int id) {
    this->id = id;
    this->name = name;
}
void TimeOff::setMaxVac(int num){
    if(num > 240) cout << "cannot allow this much vacation time\n\n";
    else maxVac = new numDays(num);
}

TimeOff::~TimeOff() {
    delete maxSickDays;
    delete sickTaken;
    delete maxVac;
    delete vacTaken;
    delete maxUnpaid;
    delete unPaidTaken;
}

