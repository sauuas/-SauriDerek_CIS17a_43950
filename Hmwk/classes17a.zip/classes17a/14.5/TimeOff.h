/* 
 * File:   TimeOff.h
 * Author: Derek
 */

#ifndef TIMEOFF_H
#define	TIMEOFF_H

#include <iostream>
#include <string>
#include "numDays.h"

using namespace std;

class TimeOff {
public:
    TimeOff(string,int);
    void setMaxSick(int num)
    {maxSickDays = new numDays(num);};
    void setSickT(int num)
    {sickTaken = new numDays(num);};
    void setMaxVac(int);
    void setVacT(int num)
    {vacTaken = new numDays(num);};
    void setMaxUn(int num)
    {maxUnpaid = new numDays(num);};
    void setPaidT(int num)
    {unPaidTaken = new numDays(num);};
    string getName()
    {return name;};
    int getId()
    {return id;};
    int getMaxSick()
    {return maxSickDays->getDay();};
    int getSickT()
    {return sickTaken->getDay();};
    int getMaxVac()
    {return maxVac->getDay();};
    int getVacT()
    {return vacTaken->getDay();};
    int getMaxUn()
    {return maxUnpaid->getDay();};
    int getPaidT()
    {return unPaidTaken->getDay();};
    
    
    virtual ~TimeOff();
private:
    string name;
    int id;
    numDays *maxSickDays;
    numDays *sickTaken;
    numDays *maxVac;
    numDays *vacTaken;
    numDays *maxUnpaid;
    numDays *unPaidTaken;

};

#endif	/* TIMEOFF_H */

