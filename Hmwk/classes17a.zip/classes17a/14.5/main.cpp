/* 
 * File:   time off
 * Author: Derek Sauri
 */

#include <iostream>
#include "TimeOff.h"

using namespace std;


int main() {
    TimeOff a("bob", 111623);   //number entered is in hours
    a.setMaxSick(44);
    a.setMaxUn(43);
    a.setMaxVac(240);
    a.setPaidT(42);
    a.setSickT(41);
    a.setVacT(40);

    cout << "maximum sick time " << a.getMaxSick() << " days\n\n";
    return 0;
}

