/* 
 * File:   Item.cpp
 * Author: Derek Sauri
 */

#include "Item.h"

Item::Item(string s, int a, float f){
    this->descrip = s;
    this->units = a;
    this->price = f;
}

Item::Item(const Item& orig) {
}

Item::~Item() {
}

