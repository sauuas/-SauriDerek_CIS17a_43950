/* 
 * File:   main.cpp
 * Author: Derek Sauri
 */

#include <iostream>
#include <iomanip>
#include "Item.h"

using namespace std;

/*
 * 
 */
int main() {
    Item a[] = {Item("jacket",12,59.95),Item("jeans",40,34.95),Item("shirt",20,24.95)};
    
    //format and print all Items elements out
    cout << setw(20) << "description\t" << "units on hand\t" << "price\n\n";
    for(int i = 0;i < 3; i++){
        cout << "item #" << i+1 << "\t" <<a[i].getDesrip() <<"\t\t" 
                << a[i].getUnit() << "\t\t" << a[i].getPrice() << "\n\n";
    }

    return 0;
}

