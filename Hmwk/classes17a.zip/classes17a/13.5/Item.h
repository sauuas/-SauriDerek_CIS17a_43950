/* 
 * File:   Item.h
 * Author: Derek Sauri
 */

#ifndef ITEM_H
#define	ITEM_H
#include <string>

using namespace std;

class Item {
public:
    Item(string, int, float);
    Item(const Item& orig);
    string getDesrip(){return this->descrip;}
    int getUnit(){return this->units;}
    float getPrice(){return this->price;}
    virtual ~Item();
private:
    string descrip;
    int units;
    float price;
};
#endif	/* ITEM_H */

