/* 
 * File:   numDays.h
 * Author: Derek
 */

#ifndef NUMDAYS_H
#define	NUMDAYS_H

class numDays {
public:
    numDays(int);
    int getHour()
    {return hours;};
    float getDay()
    {return day;};
    numDays operator +(const numDays &);
    numDays operator -(const numDays &);
    numDays operator ++();
    numDays operator ++(int);
    numDays operator --();
    numDays operator --(int);
    virtual ~numDays();
private:
    int hours;
    float day;
};

#endif	/* NUMDAYS_H */

