/* 
 * File:   numDays
 * Author: Derek Sauri
 */

#include <iostream>

#include "numDays.h"

using namespace std;


int main() {

    numDays a(8);
    numDays b(12);
    numDays c(20);
    
    //show getters
    cout << "hours " << a.getHour() << "\n\n";
    cout << "day a " << a.getDay() << "\n\n";
    cout << "day b " << b.getDay() << "\n\n";
    cout << "day c " << c.getDay() << "\n\n";
    //play with operators
    c++;
    cout << "day c++ " << c.getDay() << "\n\n";
    cout << "day a+b " << (a+b).getDay() << "\n\n";
    a--;
    cout << "day a-- " << a.getDay() << "\n\n";
    return 0;
}

