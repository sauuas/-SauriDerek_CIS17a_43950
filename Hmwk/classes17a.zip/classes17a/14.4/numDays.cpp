/* 
 * File:   numDays.cpp
 * Author: Derek
 */

#include "numDays.h"

numDays::numDays(int hours) {
    this->hours = hours;
    this->day = static_cast<float>(hours)/8;
}
numDays numDays::operator +(const numDays&right){
    numDays temp(hours);
    temp.hours = temp.hours + right.hours;
    temp.day = static_cast<float>(temp.hours)/8;
    return temp;
}
numDays numDays::operator -(const numDays&right){
    numDays temp(hours);
    temp.hours = temp.hours - right.hours;
    temp.day = static_cast<float>(temp.hours)/8;
    return temp;
}
numDays numDays::operator ++(){
    hours++;
    day = static_cast<float>(hours)/8;
    return *this;
}
numDays numDays::operator ++(int){
  numDays  temp(hours);
    hours++;
    day = static_cast<float>(hours)/8;
    return temp;
}
numDays numDays::operator --(){
    hours--;
    day = static_cast<float>(hours)/8;
    return *this;
}
numDays numDays::operator --(int){
  numDays  temp(hours);
    hours--;
    day = static_cast<float>(hours)/8;
    return temp;
}
numDays::~numDays() {
}

