/* 
 * File:  date
 * Author: Derek Sauri
 */

#include <cstdlib>
#include <iostream>

#include "Date.h"

using namespace std;

/*
 * 
 */
int main() {
    int month, day, year;
    
    do{
    cout << "enter which month (1-12)\n\n";
    cin >> month;
    }while(!cin || month < 1 || month > 12);
    do{
    cout << "enter which day (1-31)\n\n";
    cin >> day;
    }while(!cin || day < 1 || day > 31);
    do{
    cout << "enter which year (not negative)\n\n";
    cin >> year;
    }while(!cin || year < 1);
    
    Date theDate(month, day, year);
    cout << "\n\n";
    theDate.printDay();
    theDate.printDmo();
    theDate.printDnum();

    return 0;
}

