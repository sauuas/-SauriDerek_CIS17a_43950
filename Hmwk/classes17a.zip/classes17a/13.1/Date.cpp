/* 
 * File:   Date.cpp
 * Author: Derek Sauri
 * 
 */
#include <iostream>
#include "Date.h"

using namespace std;

Date::Date(int month,int day,int year){
    this->month = month;
    this->day = day;
    this->year = year;
}

Date::Date(const Date& orig) {
}
//numerical date
void Date::printDnum(){
    cout << month << "/" << day << "/" << year << "\n";
}
//month, day year format
void Date::printDmo(){
    string a[] = {"JANUARY", "FEBUARY", "MARCH", "APRIL", "MAY", "JUNE", "JULY", 
                  "AUGUST", "SEPTEMBER", "OCTOBER", "NOVEMBER", "DECEMBER"};
      cout << a[month - 1] << " " << day << ", " << year << "\n";
    
}
//day month year format
void Date::printDay(){
    string a[] = {"JANUARY", "FEBUARY", "MARCH", "APRIL", "MAY", "JUNE", "JULY", 
                  "AUGUST", "SEPTEMBER", "OCTOBER", "NOVEMBER", "DECEMBER"};
      cout << day << " " << a[month - 1] << " " << year << "\n";
}

Date::~Date() {
}

