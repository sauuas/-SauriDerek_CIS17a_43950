/* 
 * File:   Date.h
 * Author: derek
 *
 */
#ifndef DATE_H
#define	DATE_H

class Date {
public:
    Date(int,int,int);
    Date(const Date& orig);
    void printDnum(); //numerical date
    void printDmo();    //month, then day year
    void printDay();    //day, month, year
    virtual ~Date();
private:
    int month;
    int day;
    int year;
};

#endif	/* DATE_H */

