/* 
 * File:   Employee.cpp
 * Author: derek
 */

#include "Employee.h"

//empty employee
Employee::Employee (){
    depart = " ";
    name = " ";
    position = " ";
    idNum = 0;
}
//full employee
Employee::Employee (string namee, string department, string positionn, int id){
    name = namee;
    depart = department;
    position = positionn;
    idNum = id;
}
//partial employee fields
Employee::Employee (string namee, int id){
    name = namee;
    idNum = id;
    depart = " ";
    position = " ";
}

Employee::~Employee() {
}

