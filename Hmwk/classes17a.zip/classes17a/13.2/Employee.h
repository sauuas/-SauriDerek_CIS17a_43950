/* 
 * File:   Employee.h
 * Author: derek
 */

#ifndef EMPLOYEE_H
#define	EMPLOYEE_H

#include <string>

using namespace std;

class Employee {
public:
    Employee();
    Employee(string,string,string, int);
    Employee(string, int);
    string getName()
    {return name;};
    int getId()
    {return idNum;};
    string getDepart()
    {return depart;};
    string getPosi()
    {return position;};
    virtual ~Employee();
private:
    string name;
    int idNum;
    string depart;
    string position;
};

#endif	/* EMPLOYEE_H */

