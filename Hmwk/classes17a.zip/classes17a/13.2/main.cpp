/* 
 * File:   Employee class
 * Author: Derek Sauri
 */

#include<iostream>
#include<iomanip>
#include"Employee.h"

using namespace std;


int main() {
    Employee dude;
    Employee man("mike", 127653);
    Employee guy("sam","accounting","accountant",889631);
    
    //format and print out all the employees
    cout << setw(20) << left << "Name " << "ID number " << "Department   " << "Position\n";
    cout << setw(20) << left << man.getName() << " " << man.getId() << " " << man.getDepart()
         << " " << man.getPosi() << "\n";
    cout << setw(20) << left << dude.getDepart() << " " << dude.getId() << "   " << dude.getDepart()
         << " " << dude.getPosi() << "\n";
    cout << setw(20) << left << guy.getName() << " " << guy.getId() << "   " << guy.getDepart()
         << "   " << guy.getPosi() << "\n";
    

    return 0;
}

