/* 
 * File:   for tests
 */

#include <iostream>

using namespace std;

/*
 * 
 */
int main() {
    int num = 1234;
    
    cout << num/1000 << endl;
    cout << num;
    return 0;
}

