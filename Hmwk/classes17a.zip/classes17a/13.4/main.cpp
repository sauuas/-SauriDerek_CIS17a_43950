/* 
 * File: personal information
 * Author: Derek Sauri
 */

#include <iostream>

#include "Person.h"

using namespace std;

/*
 * 
 */
int main() {
    
    Person a[3] = {Person("my name", "274 pLace ave.", 19, 9283485),
    Person("his Name", "756 there ct.", 23, 4652839),
    Person("mx smith", "123 isNot dr.", 32, 8231572)};
    //print names from persons
    for(int i = 0; i< 3; i++){
        cout << "name: " << a[i].getName() << "\n";
        cout << "address: " << a[i].getAdd() << "\n";
        cout << "age: " << a[i].getAge() << "\n";
        cout << "phone number: " << a[i].getPhone() << "\n";
    }
    
    return 0;
}

