/* 
 * File:   Person.cpp
 * Author: Derek
 */

#include "Person.h"

Person::Person(string name, string add, int age, int phone) {
    this->name = name;
    this->address = add;
    this->age = age;
    this->phoneNum = phone;
}

Person::Person(const Person& orig) {
}

Person::~Person() {
}

