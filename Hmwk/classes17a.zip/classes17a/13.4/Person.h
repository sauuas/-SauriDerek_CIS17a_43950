/* 
 * File:   Person.h
 * Author: Derek
 */

#ifndef PERSON_H
#define	PERSON_H
#include <string>

using namespace std;

class Person {
public:
    Person(string, string, int, int);
    Person(const Person& orig);
    string getName(){return name;}
    string getAdd(){return address;}
    int getAge() {return age;}
    int getPhone(){return phoneNum;}
    virtual ~Person();
private:
    string name;
    string address;
    int age;
    int phoneNum;
};

#endif	/* PERSON_H */

