/* 
 * File: menu for assignment 4
 * Author: Derek Sauri
 */

#include <iostream>
#include <iomanip>

//user libraries
#include "Date.h"
#include "Employee.h"
#include "Person.h"
#include "Item.h"
#include "Inventory.h"
#include "Number.h"
#include "DayOfYear.h"
#include "DayOfYear2.h"
#include "numDays.h"
#include "TimeOff.h"

using namespace std;

//prototypes
void pro1();
void pro2();
void pro3();
void pro4();
void pro5();
void printObj(Inventory );  //with problem 5
void pro6();
void pro7();
void pro8();
void pro9();
void pro10();

int main(int argc, char** argv) {
    int choice;
    
    cout << "pick a problem\n\n"
            "1: 13.1\n"
            "2: 13.2\n"
            "3: 13.4\n"
            "4: 13.5\n"
            "5: 13.6\n"
            "6: 14.1\n"
            "7: 14.2\n"
            "8: 14.3\n"
            "9: 14.4\n"
            "10: 14.5\n";
    cin >> choice;cin.ignore();
    switch(choice){
        case 1:pro1();break;
        case 2:pro2();break;
        case 3:pro3();break;
        case 4:pro4();break;
        case 5:pro5();break;
        case 6:pro6();break;
        case 7:pro7();break;
        case 8:pro8();break;
        case 9:pro9();break;
        case 10:pro10();break;
    }

    return 0;
}
//problem 1
void pro1(){
    int month, day, year;
    
    do{
    cout << "enter which month (1-12)\n\n";
    cin >> month;
    }while(!cin || month < 1 || month > 12);
    do{
    cout << "enter which day (1-31)\n\n";
    cin >> day;
    }while(!cin || day < 1 || day > 31);
    do{
    cout << "enter which year (not negative)\n\n";
    cin >> year;
    }while(!cin || year < 1);
    
    Date theDate(month, day, year);
    cout << "\n\n";
    theDate.printDay();
    theDate.printDmo();
    theDate.printDnum();

}
//problem 2
void pro2(){
     Employee dude;
    Employee man("mike", 127653);
    Employee guy("sam","accounting","accountant",889631);
    
    //format and print out all the employees
    cout << setw(20) << left << "Name " << "ID number " << "Department   " << "Position\n";
    cout << setw(20) << left << man.getName() << " " << man.getId() << " " << man.getDepart()
         << " " << man.getPosi() << "\n";
    cout << setw(20) << left << dude.getDepart() << " " << dude.getId() << "   " << dude.getDepart()
         << " " << dude.getPosi() << "\n";
    cout << setw(20) << left << guy.getName() << " " << guy.getId() << "   " << guy.getDepart()
         << "   " << guy.getPosi() << "\n";
    
}
//problem 3
void pro3(){
     Person a[3] = {Person("my name", "274 pLace ave.", 19, 9283485),
    Person("his Name", "756 there ct.", 23, 4652839),
    Person("mx smith", "123 isNot dr.", 32, 8231572)};
    //print names from persons
    for(int i = 0; i< 3; i++){
        cout << "name: " << a[i].getName() << "\n";
        cout << "address: " << a[i].getAdd() << "\n";
        cout << "age: " << a[i].getAge() << "\n";
        cout << "phone number: " << a[i].getPhone() << "\n";
    }
}
//problem 4
void pro4(){
     Item a[] = {Item("jacket",12,59.95),Item("jeans",40,34.95),Item("shirt",20,24.95)};
    
    //format and print all Items elements out
    cout << setw(20) << "description\t" << "units on hand\t" << "price\n\n";
    for(int i = 0;i < 3; i++){
        cout << "item #" << i+1 << "\t" <<a[i].getDesrip() <<"\t\t" 
                << a[i].getUnit() << "\t\t" << a[i].getPrice() << "\n\n";
    }
}
//problem 5
void pro5(){
     Inventory thing1;
    int item;
    int units;
    float cost;
    //show default constructor
    cout << "created new object\n\n\n";
    printObj(thing1);
    //alter members
    cout << "altering members\n\n\n";
    thing1.setCost(1.5);
    thing1.setItem(13242);
    thing1.setQuant(34);
     printObj(thing1);
     //create with other constructor
     cout << "second constructor requires input\n";
     do{
         cout<< "input item number(must be positive)\n";
         cin >> item;
     }while(item < 1);
      do{
         cout<< "input quantity(must be positive)\n";
         cin >> units;
     }while(units < 1);
      do{
         cout<< "input cost per unit(must be positive)\n";
         cin >> cost;
     }while(cost < 1);
     Inventory thing2(item,units,cost);
     printObj(thing2);
}
//print out inventory object
void printObj(Inventory a){
    cout << "item number " << a.getItem() << "\n\n";
    cout << "quantity " << a.getQuant() << "\n\n";
    cout << "cost per unit " << a.getCost() << "\n\n";
    cout << "total cost " << a.getTotal() << "\n\n";
    
}
//problem 6
void pro6(){
   Number num(1219);
    //print text value of number
    num.print();
}
//problem 7
void pro7(){
    DayOfYear a(47),b(31),c(333);
    a.print();
    b.print();
    c.print();
}
//problem 8
void pro8(){
     DayOfYear2 a("December",31);
    a.print();
    a++;
    a.print();
    a--;
    a.print();
}
//problem 9
void pro9(){
     numDays a(8);
    numDays b(12);
    numDays c(20);
    
    //show getters
    cout << "hours " << a.getHour() << "\n\n";
    cout << "day a " << a.getDay() << "\n\n";
    cout << "day b " << b.getDay() << "\n\n";
    cout << "day c " << c.getDay() << "\n\n";
    //play with operators
    c++;
    cout << "day c++ " << c.getDay() << "\n\n";
    cout << "day a+b " << (a+b).getDay() << "\n\n";
    a--;
    cout << "day a-- " << a.getDay() << "\n\n";
}
//problem 10
void pro10(){
     TimeOff a("bob", 111623);   //number entered is in hours
    a.setMaxSick(44);
    a.setMaxUn(43);
    a.setMaxVac(240);
    a.setPaidT(42);
    a.setSickT(41);
    a.setVacT(40);

    cout << "maximum sick time " << a.getMaxSick() << " days\n\n";
}