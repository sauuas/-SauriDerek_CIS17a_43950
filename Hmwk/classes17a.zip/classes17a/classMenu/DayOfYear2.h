/* 
 * File:   DayOfYear2.h
 * Author: derek
 */

#ifndef DAYOFYEAR2_H
#define	DAYOFYEAR2_H

#include <string>

using namespace std;

class DayOfYear2 {
public:
    DayOfYear2(int);
    DayOfYear2(string, int);
   void print();
   DayOfYear2 operator ++();
   DayOfYear2 operator ++(int);
   DayOfYear2 operator --();
   DayOfYear2 operator --(int);
    virtual ~DayOfYear2();
private:
    string month;
    int day;

};

#endif	/* DAYOFYEAR2_H */

