/* 
 * File:   numbers class
 * Author: Derek Sauri
 */

#include <iostream>

#include "Number.h"

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {
    Number num(1219);
    //print text value of number
    num.print();
    return 0;
}

