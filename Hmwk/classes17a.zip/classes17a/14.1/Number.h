/* 
 * File:   Number.h
 * Author: Derek
 */

#ifndef NUMBER_H
#define	NUMBER_H
#include <string>

using namespace std;
class Number {
public:
    Number(int);
   void print();
    virtual ~Number();
private:
    int number;
};

#endif	/* NUMBER_H */

