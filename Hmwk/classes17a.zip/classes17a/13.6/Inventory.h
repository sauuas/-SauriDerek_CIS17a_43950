/* 
 * File:   Inventory.h
 * Author: Derek Sauri
 */

#ifndef INVENTORY_H
#define	INVENTORY_H

class Inventory {
public:
    Inventory();
    Inventory(int, int, float);
    void setItem(int i){itemNum = i;}
    void setQuant(int q){quantity = q;}
    void setCost(float c){cost = c;}
    int getItem(){return itemNum;}
    int getQuant(){return quantity;}
    float getCost(){return cost;}
    float getTotal();
    virtual ~Inventory();
private:
    int itemNum;
    int quantity;
    float cost;
    float total;
  void setTotal(){total = cost*quantity;}
};

#endif	/* INVENTORY_H */

