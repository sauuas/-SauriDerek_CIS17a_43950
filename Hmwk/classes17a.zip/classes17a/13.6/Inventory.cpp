/* 
 * File:   Inventory.cpp
 * Author: Derek Sauri
 */

#include "Inventory.h"

//empty inventory
Inventory::Inventory() {
    itemNum = 0;
    quantity = 0;
    cost = 0;
}
//filled inventory item
Inventory::Inventory(int item, int quant, float cost){
    setItem(item);
    setQuant(quant);
    setCost(cost);
}
float Inventory::getTotal(){
    setTotal();
    return total;
}

Inventory::~Inventory() {
}

