/* 
 * File:   main.cpp
 * Author: Derek Sauri
 */

#include <iostream>

#include "Inventory.h"

using namespace std;

//prototypes
void printObj(Inventory );

int main() {
    Inventory thing1;
    int item;
    int units;
    float cost;
    //show default constructor
    cout << "created new object\n\n\n";
    printObj(thing1);
    //alter members
    cout << "altering members\n\n\n";
    thing1.setCost(1.5);
    thing1.setItem(13242);
    thing1.setQuant(34);
     printObj(thing1);
     //create with other constructor
     cout << "second constructor requires input\n";
     do{
         cout<< "input item number(must be positive)\n";
         cin >> item;
     }while(item < 1);
      do{
         cout<< "input quantity(must be positive)\n";
         cin >> units;
     }while(units < 1);
      do{
         cout<< "input cost per unit(must be positive)\n";
         cin >> cost;
     }while(cost < 1);
     Inventory thing2(item,units,cost);
     printObj(thing2);
    return 0;
}
//print out inventory object
void printObj(Inventory a){
    cout << "item number " << a.getItem() << "\n\n";
    cout << "quantity " << a.getQuant() << "\n\n";
    cout << "cost per unit " << a.getCost() << "\n\n";
    cout << "total cost " << a.getTotal() << "\n\n";
    
}
