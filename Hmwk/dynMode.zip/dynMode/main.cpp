/* Dynamic array practice 
 * Derek Sauri
 */

#include <iostream>
#include <cstdlib>
#include <ctime>

using namespace std;

// prototypes
void fillArray(int[], int);
void sortArray(int[], int);
void printArray(int [], int);
void numModes(int[],int, int& ,int&);
void fillDynA(int[], int[], int, int&);
void printDynA(int []);

/*
 * find the mode in the given array and create a dynamic array to store contents
 */
int main() {
    const int arraySize = 10;
    int feq= 0;
    int numMode= 0;
    int *dynA;
    int a[arraySize];
    
    fillArray(a, arraySize);
    sortArray(a, arraySize);
    printArray(a, arraySize);
    // find the number of modes and the highest frequency
    numModes(a,arraySize,numMode, feq);
    // if no mode
    if (feq < 2){
        cout << "there is no mode.\n";
        return 0;
    }
    
    dynA = new int[numMode + 2];
    dynA[0] = numMode;
    dynA[1] = feq;
    fillDynA(dynA, a, arraySize, feq);
    printDynA(dynA);
    delete [] dynA;
    return 0;
}
void fillArray(int a[],int asize){
    srand(time(0));
    
    for(int i = 0; i < asize; i++){
        a[i] = rand() % 11;
    }
}
void sortArray(int a[],int asize){
    for (int i = 0; i < asize; i++){
        int small = i;
        int temp;
        for(int j = i;j < asize; j++){
            if(a[j] < a[small])
                small = j;
        }
        temp = a[i];
        a[i]= a[small];
        a[small] = temp;
    }
}
void printArray(int a[],int asize){
    for (int i = 0;i < asize; i++){
        cout << a[i] << " ";
    }
    cout << endl;
}
void numModes(int a[],int arraySize,int &numMode,int &feq){
    int temp = a[0];
    int count= 0;
    int max = 0;
    // find highest frequency
        for (int i =0;i < arraySize;i++){
            if (a[i]== temp){
                count++;
            }
            else if(a[i] != temp){
                    if (count > max){
                        max = count;
                    }
                temp = a[i];
                count = 1;
            }
        }
    if (count > max){
         max = count;
     }
     feq = max;
     // find number of modes
     temp = a[0];
     count = 0;
    for (int i =0;i < arraySize;i++){
            if (a[i]== temp){
                count++;
            }
            else if(a[i] != temp){
                if (count == max){
                    numMode++;
                }
                temp = a[i];
                count = 1;
            }
        }
     if (count == max){
         numMode++;
        }
}
void fillDynA(int dynA[], int a[], int aSize, int &feq){
    int temp = a[0];
    int count= 0;
    int i = 2;
        
            for (int j =0;j < aSize;j++){
                if (a[j]== temp){
                    count++;
                }
                else if(a[j] != temp){
                    if (count == feq){
                        dynA[i] = temp;
                        i++;
                    }
                    temp = a[j];
                    count = 1;
                   }  
            }
    if (count == feq){
        dynA[i] = temp;
     }
}
void printDynA(int a[]){
    cout << "the number of modes is " << a[0] << endl;
    cout << "the highest frequency is " << a[1] << endl;
    for (int i = 2;i < a[0]+2; i++){
        cout << a[i] << " ";
    }
    cout << endl;
}
